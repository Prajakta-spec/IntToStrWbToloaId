package com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.security.ping;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.server.resource.authentication.AbstractOAuth2TokenAuthenticationToken;

import java.util.Collection;
import java.util.Map;

public class PingToken extends AbstractOAuth2TokenAuthenticationToken<Jwt> {

  public PingToken(final Collection<? extends GrantedAuthority> authorities, final Jwt jwt) {
    super(jwt, jwt.getClaimAsString("client_id"), jwt, authorities);
    super.setAuthenticated(true);
  }

  @Override
  public Map<String, Object> getTokenAttributes() {
    return this.getToken().getClaims();
  }

  @Override
  public void setAuthenticated(final boolean authenticated) {
    if (authenticated) {
      throw new IllegalArgumentException("Cannot upgrade a token to be authenticated.");
    } else {
      super.setAuthenticated(false);
    }
  }
}