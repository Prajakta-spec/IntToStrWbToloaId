package com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.security.ping;

import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.constants.Constants;
import com.nimbusds.jose.JOSEException;
import com.nimbusds.jose.JWSAlgorithm;
import com.nimbusds.jose.jwk.JWKSet;
import com.nimbusds.jose.jwk.RSAKey;
import com.nimbusds.jose.jwk.source.ImmutableJWKSet;
import com.nimbusds.jose.jwk.source.JWKSource;
import com.nimbusds.jose.proc.BadJOSEException;
import com.nimbusds.jose.proc.JWSKeySelector;
import com.nimbusds.jose.proc.JWSVerificationKeySelector;
import com.nimbusds.jose.proc.SecurityContext;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.proc.DefaultJWTProcessor;
import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

import java.security.interfaces.RSAPublicKey;
import java.text.ParseException;

@Slf4j
@Configuration
@Profile({
  Constants.LOCAL_ENVIRONMENT,
  Constants.DEVELOPMENT_ENVIRONMENT,
  Constants.TEST_ENVIRONMENT,
  Constants.STAGING_ENVIRONMENT,
  Constants.PERFORMANCE_ENVIRONMENT,
  Constants.INTEGRATION_ENVIRONMENT,
  Constants.PRODUCTION_ENVIRONMENT
})
public class PingJwtProcessor extends DefaultJWTProcessor<SecurityContext> {
  private final PingSigningCertificateProvider pingSigningCertificateProvider;

  public PingJwtProcessor(final PingSigningCertificateProvider pingSigningCertificateProvider) {
    this.pingSigningCertificateProvider = pingSigningCertificateProvider;
  }

  @Override
  public JWTClaimsSet process(final String jwtString, final SecurityContext context)
      throws BadJOSEException, ParseException, JOSEException {
    setSigningCert();
    return super.process(jwtString, context);
  }

  @PostConstruct
  void setSigningCert() {
    RSAKey jwk;
    try {
      jwk =
          new RSAKey.Builder((RSAPublicKey) pingSigningCertificateProvider.apply().getPublicKey())
              .keyID(Constants.PING_JWT_KEY_ID)
              .build();
      final JWKSet jwkSet = new JWKSet(jwk);
      final JWKSource<SecurityContext> keySource = new ImmutableJWKSet<>(jwkSet);
      final JWSKeySelector<SecurityContext> keySelector =
          new JWSVerificationKeySelector<>(
              JWSAlgorithm.parse(Constants.PING_JWS_ALGORITHM), keySource);
      this.setJWSKeySelector(keySelector);
    } catch (PingException pingException) {
      log.error(
          "PingException thrown in PingJwtProcessor.setSigningCert() with the message: {}",
          pingException.getMessage());
    }
  }
}
