package com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.graph.error;

/**
 * Represents the complete error response structure from Microsoft Graph API.
 * Maps the JSON error response to Java records for type safety.
 *
 * @param error the main error details
 */
public record GraphApiErrorResponse(ErrorDetail error) {

    /**
     * Detailed error information from Graph API response.
     *
     * @param code the error code
     * @param message the error message
     * @param innerError additional error details
     */
    public record ErrorDetail(String code, String message, InnerErrorDetail innerError) {

        /**
         * Inner error details containing request tracking information.
         *
         * @param date timestamp of the error
         * @param request_id Graph API request identifier
         * @param client_request_id client-provided request identifier
         */
        public record InnerErrorDetail(String date, String request_id, String client_request_id) {}
    }
}
