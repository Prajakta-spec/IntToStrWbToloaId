package com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.graph.exceptions;

import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.graph.error.ErrorDetail;
import lombok.Getter;
import org.springframework.http.HttpStatusCode;

import java.util.List;

@Getter
public class ServiceException extends RuntimeException {

    private final List<ErrorDetail> errors;
    private final HttpStatusCode status;

    public ServiceException(final List<ErrorDetail> serviceErrors, final HttpStatusCode serviceStatus) {
        super(buildErrorMessage(serviceErrors, serviceStatus));
        this.errors = serviceErrors != null ? serviceErrors : List.of();
        this.status = serviceStatus;
    }

    private static String buildErrorMessage(List<ErrorDetail> errors, HttpStatusCode status) {
        if (errors == null || errors.isEmpty()) {
            return String.format("Service error with status %s: Unknown error", status);
        }

        ErrorDetail firstError = errors.get(0);
        String errorCode = firstError.code() != null ? String.format(" [%s]", firstError.code()) : "";
        return String.format("Service error with status %s%s: %s",
                status,
                errorCode,
                firstError.message() != null ? firstError.message() : "No error message provided");
    }
}
