package com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.graph.response;

public record AzureTokenResponse(String token_type, Integer expires_in, Integer ext_expires_in, String access_token) {}
