package com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.graph.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.constants.Constants;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.graph.error.ErrorDetail;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.graph.exceptions.ServiceException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.http.HttpStatusCode;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.ExchangeFilterFunction;
import reactor.core.publisher.Mono;

import java.time.Duration;
import java.time.Instant;
import java.util.List;
import java.util.function.Function;

/**
 * Utility class for WebClient configuration and common functionality.
 * Provides logging, error handling, and request/response processing capabilities.
 */
public final class WebClientUtil {

    private static final Logger LOGGER = LoggerFactory.getLogger(WebClientUtil.class);
    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();

    private WebClientUtil() {
        throw new UnsupportedOperationException("WebClientUtil is a utility class and should not be instantiated");
    }

    /**
     * Creates an exchange filter function for logging request and response information.
     * Includes timing, status codes, and correlation IDs for observability.
     *
     * @param logger the logger to use for output
     * @return configured ExchangeFilterFunction for logging
     */
    public static ExchangeFilterFunction logRequestAndResponseInformation(final Logger logger) {
        return (clientRequest, next) -> {
            logger.info("Request for: {}, method: {} started", clientRequest.url(), clientRequest.method());
            Instant start = Instant.now();
            String trackingId = MDC.get(Constants.TRACKING_ID);

            return next
                .exchange(clientRequest)
                .doOnNext(clientResponse -> {
                    MDC.put(Constants.TRACKING_ID, trackingId);
                    Duration duration = Duration.between(start, Instant.now());

                    // Structured logging with additional context
                    if (clientResponse.statusCode().isError()) {
                        logger.warn(
                            "Request for: {} completed with error, status: {}, duration: {} ms, trackingId: {}",
                            clientRequest.url(),
                            clientResponse.statusCode(),
                            duration.toMillis(),
                            trackingId
                        );
                    } else {
                        logger.info(
                            "Request for: {} completed successfully, status: {}, duration: {} ms, trackingId: {}",
                            clientRequest.url(),
                            clientResponse.statusCode(),
                            duration.toMillis(),
                            trackingId
                        );
                    }
                })
                .doOnError(throwable -> {
                    MDC.put(Constants.TRACKING_ID, trackingId);
                    Duration duration = Duration.between(start, Instant.now());
                    logger.error(
                        "Request for: {} failed with exception, duration: {} ms, trackingId: {}, error: {}",
                        clientRequest.url(),
                        duration.toMillis(),
                        trackingId,
                        throwable.getMessage(),
                        throwable
                    );
                });
        };
    }

    /**
     * Creates an exchange filter function for logging using the default logger.
     *
     * @return configured ExchangeFilterFunction for logging
     */
    public static ExchangeFilterFunction logRequestAndResponseInformation() {
        return logRequestAndResponseInformation(LOGGER);
    }

    /**
     * Creates an exchange filter function for handling error responses.
     * Parses error responses and converts them to ServiceExceptions.
     *
     * @param errorDetailExtractor function to extract ErrorDetail from error response
     * @param errorResponseType the class type of the error response
     * @param logger logger for error reporting
     * @param <T> the type of the error response
     * @return configured ExchangeFilterFunction for error handling
     */
    public static <T> ExchangeFilterFunction handleResponseErrors(
        final Function<T, ErrorDetail> errorDetailExtractor,
        final Class<T> errorResponseType,
        final Logger logger
    ) {
        return ExchangeFilterFunction.ofResponseProcessor(clientResponse -> {
            if (clientResponse.statusCode().isError()) {
                return clientResponse
                    .bodyToMono(String.class)
                    .flatMap(rawBody -> parseErrorResponse(
                        rawBody,
                        errorResponseType,
                        errorDetailExtractor,
                        clientResponse.statusCode(),
                        logger
                    ));
            } else {
                return Mono.just(clientResponse);
            }
        });
    }

    /**
     * Parses error response body and creates appropriate ServiceException.
     *
     * @param rawBody the raw response body
     * @param errorResponseType the expected error response type
     * @param errorDetailExtractor function to extract error details
     * @param statusCode the HTTP status code
     * @param logger logger for error reporting
     * @param <T> the type of the error response
     * @return Mono that emits ServiceException
     */
    public static <T> Mono<ClientResponse> parseErrorResponse(
        final String rawBody,
        final Class<T> errorResponseType,
        final Function<T, ErrorDetail> errorDetailExtractor,
        final HttpStatusCode statusCode,
        final Logger logger
    ) {
        try {
            T errorResponse = OBJECT_MAPPER.readValue(rawBody, errorResponseType);
            ErrorDetail errorDetail = errorDetailExtractor.apply(errorResponse);

            logger.error(
                "Service error response parsed - Status: {}, Code: {}, Message: {}, Raw: {}",
                statusCode,
                errorDetail.code(),
                errorDetail.message(),
                rawBody
            );

            return Mono.error(new ServiceException(List.of(errorDetail), statusCode));

        } catch (JsonProcessingException e) {
            logger.error(
                "Failed to parse error response - Status: {}, Raw body: {}, Parse error: {}",
                statusCode,
                rawBody,
                e.getMessage(),
                e
            );

            // Create a fallback error detail when parsing fails
            ErrorDetail fallbackError = new ErrorDetail(
                "Failed to parse error response: " + e.getMessage(),
                "PARSE_ERROR"
            );

            return Mono.error(new ServiceException(List.of(fallbackError), statusCode));
        }
    }
}
