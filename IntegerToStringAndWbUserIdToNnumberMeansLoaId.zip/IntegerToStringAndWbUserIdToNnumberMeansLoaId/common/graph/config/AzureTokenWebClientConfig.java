package com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.graph.config;

import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.graph.error.ErrorDetail;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.graph.response.AzureTokenErrorResponse;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.graph.util.WebClientUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.client.ExchangeFilterFunction;
import org.springframework.web.reactive.function.client.WebClient;

@Configuration
public class AzureTokenWebClientConfig {
    private static final Logger LOGGER = LoggerFactory.getLogger(AzureTokenWebClientConfig.class);

    @Value("${microsoft.azure.base-url}")
    private String baseUrl;

    @Bean(name = "azureWebClient")
    public WebClient webClient() {
        return WebClient.builder()
                .baseUrl(baseUrl)
                .defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_FORM_URLENCODED_VALUE)
                .filter(WebClientUtil.logRequestAndResponseInformation())
                .filter(handleResponseErrors())
                .build();
    }

   public static ExchangeFilterFunction handleResponseErrors() {
        return WebClientUtil.handleResponseErrors(
                errorResponse -> new ErrorDetail(errorResponse.error_description(), errorResponse.error()),
                AzureTokenErrorResponse.class,
                LOGGER
        );
    }
}
