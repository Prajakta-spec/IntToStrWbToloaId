package com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.graph.config;

import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.graph.error.ErrorDetail;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.graph.error.GraphApiErrorResponse;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.graph.util.WebClientUtil;
import io.netty.channel.ChannelOption;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.web.reactive.function.client.ExchangeFilterFunction;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.netty.http.client.HttpClient;

import java.time.Duration;

/**
 * Configuration class for Microsoft Graph API WebClient.
 * Provides configured WebClient beans with proper error handling and logging.
 */
@Configuration
public class GraphApiWebClientConfig {

    private static final Logger LOGGER = LoggerFactory.getLogger(GraphApiWebClientConfig.class);

    // Property name constants
    private static final String GRAPH_API_BASE_URL_PROPERTY = "${microsoft.graph-api.base-url}";
    private static final String GRAPH_API_TIMEOUT_PROPERTY = "${microsoft.graph-api.timeout:30}";

    // Timeout configurations
    private static final Duration DEFAULT_CONNECTION_TIMEOUT = Duration.ofSeconds(10);

    @Value(GRAPH_API_BASE_URL_PROPERTY)
    private String baseUrl;

    @Value(GRAPH_API_TIMEOUT_PROPERTY)
    private int timeoutSeconds;

    /**
     * Creates a configured WebClient for Microsoft Graph API calls.
     * Includes logging, error handling, and timeout configurations.
     *
     * @return configured WebClient instance
     */
    @Bean(name = "graphApiWebClient")
    public WebClient webClient() {
        HttpClient httpClient = HttpClient.create()
                .responseTimeout(Duration.ofSeconds(timeoutSeconds))
                .option(ChannelOption.CONNECT_TIMEOUT_MILLIS,
                        (int) DEFAULT_CONNECTION_TIMEOUT.toMillis());

        return WebClient.builder()
            .baseUrl(baseUrl)
            .clientConnector(new ReactorClientHttpConnector(httpClient))
            .filter(WebClientUtil.logRequestAndResponseInformation())
            .filter(handleResponseErrors())
            .build();
    }

    /**
     * Creates an exchange filter function for handling Graph API error responses.
     *
     * @return configured ExchangeFilterFunction for error handling
     */
    public static ExchangeFilterFunction handleResponseErrors() {
        return WebClientUtil.handleResponseErrors(
            errorResponse -> new ErrorDetail(errorResponse.error().message(), errorResponse.error().code()),
            GraphApiErrorResponse.class,
            LOGGER
        );
    }
}
