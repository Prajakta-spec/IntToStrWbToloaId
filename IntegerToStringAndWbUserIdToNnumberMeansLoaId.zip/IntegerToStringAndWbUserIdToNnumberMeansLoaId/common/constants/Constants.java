package com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.constants;

public final class Constants {
  public static final String LOCAL_ENVIRONMENT = "local";
  public static final String INTEGRATION_TEST_ENVIRONMENT = "integrationtest";
  public static final String LOCAL_DOCKER_ENVIRONMENT = "localdocker";
  public static final String DEVELOPMENT_ENVIRONMENT = "development";
  public static final String TEST_ENVIRONMENT = "test";
  public static final String STAGING_ENVIRONMENT = "staging";
  public static final String PERFORMANCE_ENVIRONMENT = "performance";
  public static final String INTEGRATION_ENVIRONMENT = "integration";
  public static final String PRODUCTION_ENVIRONMENT = "production";
  public static final String OBLIGEE_METADATA_BASE_ENDPOINT = "/api/v1/obligee/";
  public static final String OBLIGEE_ID_PATH_PARAMETER = "obligee-id";
  public static final String OBLIGEE_ID_DYNAMIC_PATH_PARAMETER =
          "{" + OBLIGEE_ID_PATH_PARAMETER + "}";
  public static final String OBLIGEE_METADATA_DYNAMODB_TABLE = "grs-obligee-document-mgmt-metadata";
  public static final String WB_USER_ID_PARAMETER_1 = "INDIVIDUAL-ID";
  public static final String INTEGER_GREATER_THAN_ZERO_ERROR_MSG =
          " is an Integer an should be greater than zero";
  public static final String PARAMETER_GREATER_THAN_ZERO = " parameter cannot be negative or zero";
  public static final String CATEGORY_ID_PATCH_PARAMETER = "categoryId";
  public static final String CATEGORY_ID_PATCH_GREATER_THAN_ZERO_MSG =
          CATEGORY_ID_PATCH_PARAMETER + PARAMETER_GREATER_THAN_ZERO;
  public static final String SUB_CATEGORY_ID_PATCH_PARAMETER = "subCategoryId";
  public static final String SUB_CATEGORY_ID_PATCH_GREATER_THAN_ZERO_MSG =
          SUB_CATEGORY_ID_PATCH_PARAMETER + PARAMETER_GREATER_THAN_ZERO;
  public static final String CREATED_BY_ID_PATCH_PARAMETER = "createdById";
  public static final String UPDATED_BY_ID_PATCH_PARAMETER = "updatedById";
  public static final String UPDATED_BY_ID_PATCH_GREATER_THAN_ZERO_MSG =
          UPDATED_BY_ID_PATCH_PARAMETER + PARAMETER_GREATER_THAN_ZERO;
  public static final String CREATED_BY_ID_PATCH_GREATER_THAN_ZERO_MSG =
          CREATED_BY_ID_PATCH_PARAMETER + PARAMETER_GREATER_THAN_ZERO;
  public static final String REGEX_RECEIVED_DATE_PARAMETER =
          "^\\d{4}\\-(0[1-9]|1[012])\\-(0[1-9]|[12][0-9]|3[01])$";
  public static final String INVALID_RECEIVED_DATE_PATCH_MESSAGE =
          " receivedDate parameter does not match yyyy-MM-dd format";
  public static final String INVALID_PAYMENT_DATE_PATCH_MESSAGE =
          " paymentDate parameter does not match yyyy-MM-dd format";
  public static final Integer LOCAL_CATEGORY_SUB_CATEGORY_ID_11 = 11;
  public static final String DOCUMENT_METADATA_PATH = "/document-metadata";
  public static final String PATH_PARAMETER_IS_REQUIRED = " path parameter is required";
  public static final String OBLIGEE_ID_REQUIRED_MSG =
          OBLIGEE_ID_PATH_PARAMETER + PATH_PARAMETER_IS_REQUIRED;
  public static final String OBLIGEE_ID_GREATER_THAN_ZERO_MSG =
          OBLIGEE_ID_PATH_PARAMETER + PARAMETER_GREATER_THAN_ZERO;
  public static final String OBLIGEE_ID_NOT_VALID_INTEGER_MSG =
          OBLIGEE_ID_PATH_PARAMETER + " path parameter is not a valid Integer";
  public static final String DEFAULT_DOCUMENT_RESIDENCY_COUNTRY_CODE = "USA";
  public static final String OBLIGEE_METADATA_DYNAMODB_ARCHIVE_TABLE =
          "grs-obligee-document-mgmt-archive-metadata";


  public static final Integer LOCAL_OBLIGEE_ID_147853025 = 147853025;
  public static final Integer LOCAL_OBLIGEE_ID_286412212 = 286412212;
  public static final Integer LOCAL_OBLIGEE_ID_158759469 = 158759469;
  public static final Integer LOCAL_OBLIGEE_ID_158759470 = 158759470;
  public static final Integer LOCAL_OBLIGEE_ID_587524897 = 587524897;

  public static final Integer LOCAL_OBLIGEE_ID_FOR_STORE = 999999998;
  public static final Integer LOCAL_OBLIGEE_ID_FOR_RESTORE = 888888888;
  public static final Integer LOCAL_OBLIGEE_ID_FOR_RESTORE_2 = 999999999;


  public static final Integer LOCAL_CATEGORY_SUB_CATEGORY_ID_1 = 1;
  public static final Integer LOCAL_CATEGORY_SUB_CATEGORY_ID_2 = 2;
  public static final Integer LOCAL_CATEGORY_SUB_CATEGORY_ID_3 = 3;
  public static final Integer LOCAL_CATEGORY_SUB_CATEGORY_ID_4 = 4;
  public static final Integer LOCAL_CATEGORY_SUB_CATEGORY_ID_5 = 5;
  public static final Integer LOCAL_CATEGORY_SUB_CATEGORY_ID_6 = 6;
  public static final Integer LOCAL_CATEGORY_SUB_CATEGORY_ID_7 = 7;
  public static final Integer LOCAL_CATEGORY_SUB_CATEGORY_ID_8 = 8;
  public static final Integer LOCAL_CATEGORY_SUB_CATEGORY_ID_10 = 10;
  public static final Integer LOCAL_CATEGORY_SUB_CATEGORY_ID_NEGATIVE = -1;
  public static final Integer LOCAL_CATEGORY_SUB_CATEGORY_ID_ZERO = 0;



  public static final Double LOCAL_FILE_SIZE_BYTES_1 = 1042157.0;
  public static final Double LOCAL_FILE_SIZE_BYTES_2 = 1031680.0;
  public static final Double LOCAL_FILE_SIZE_BYTES_3 = 122501.0;
  public static final Double LOCAL_FILE_SIZE_BYTES_6 = 4767232.0;
  public static final Double LOCAL_FILE_SIZE_BYTES_7 = 12726.0;
  public static final Double LOCAL_FILE_SIZE_BYTES_8 = 39936.0;


  public static final Integer LOCAL_USER_ID_2290 = 2290;
  public static final Integer LOCAL_USER_ID_1822 = 1822;
  public static final Integer LOCAL_USER_ID_2053 = 2053;
  public static final Integer LOCAL_USER_ID_2962 = 2962;
  public static final Integer LOCAL_USER_ID_FOR_DELETE_ARCHIVE = 2222;
  public static final Integer LOCAL_USER_ID_ZERO = 0;
  public static final Integer LOCAL_USER_ID_NEGATIVE = -1;
  public static final Integer LOCAL_OBLIGEE_ID_FOR_ARCHIVE_MAIN_TABLE = 288884888;

  public static final Integer LOCAL_DOC_MGMT_USER_ID_2962 = 2962;
  public static final Integer LOCAL_USER_ID_11111_NOT_FOUND_IN_REDIS = 11111;

  public static final String OBLIGEE_MULTIPART_FILE_PARAMETER = "file";
  public static final String CATEGORY_ID_PARAMETER = "Category-ID";
  public static final String SUB_CATEGORY_ID_PARAMETER = "Sub-Category-ID";
  public static final String RECEIVED_DATE_PARAMETER = "Received-Date";
  public static final String PAYMENT_DATE_PARAMETER = "Payment-Date";
  public static final String REISSUE_PARAMETER = "Reissue";
  public static final String CHECK_EFT_NUM_PARAMETER = "Check-Eft-Num";
  public static final String NOTES_PARAMETER = "Notes";
  public static final String NPPI_PARAMETER = "Nppi";
  public static final String DOCUMENT_RESIDENCY_PARAMETER = "Document-Residency";
  public static final String ENVOY_SERVICE_META_HEADER = "ServiceMeta";
  public static final Integer BILLING_DOCUMENT_CATEGORY_ID_4 = 4;
  public static final Integer BILLING_DOCUMENT_CATEGORY_ID_5 = 5;
  public static final String INVALID_RECEIVED_DATE_REGEX_MESSAGE =
          RECEIVED_DATE_PARAMETER + " parameter does not " + "match yyyy-MM-dd format";
  public static final String INVALID_PAYMENT_DATE_REGEX_MESSAGE =
          PAYMENT_DATE_PARAMETER + " parameter does not " + "match yyyy-MM-dd format";
  public static final String ISO_ALPHA3_COUNTRY_CODE_REGEX = "^([A-Z]{3})$";
  public static final String DEV_AGENCY_DOC_MGMT_UI =
          "https://dev-surety-wb-agency-docmgmt.lmig.com";
  public static final String QA_AGENCY_DOC_MGMT_UI = "https://qa-surety-wb-agency-docmgmt.lmig.com";
  public static final String UAT_AGENCY_DOC_MGMT_UI =
          "https://uat-surety-wb-agency-docmgmt.lmig.com";
  public static final String PERF_AGENCY_DOC_MGMT_UI =
          "https://perf-surety-wb-agency-docmgmt.lmig.com";
  public static final String INT_AGENCY_DOC_MGMT_UI =
          "https://int-surety-wb-agency-docmgmt.lmig.com";
  public static final String PROD_AGENCY_DOC_MGMT_UI = "https://surety-wb-agency-docmgmt.lmig.com";
  public static final String LOCAL_AGENCY_DOC_MGMT_UI = "http://localhost:4200";
  public static final String LOCAL_AGENCY_DOC_MGMT_UI_SSL = "https://localhost:4200";
  public static final String AUTH0_CLAIM_NAME = "https://lmig.com/authorization_details";
  public static final String PING_READ = "read";
  public static final String PING_WRITE = "write";
  public static final String PING_DELETE = "delete";
  public static final String AUTH0_READ = "auth0_read";
  public static final String AUTH0_WRITE = "auth0_write";
  public static final String AUTH0_DELETE = "auth0_delete";
  public static final String SCOPE_OPENID = "SCOPE_openid";
  public static final String SCOPE_PROFILE = "SCOPE_profile";
  public static final String SCOPE_EMAIL = "SCOPE_email";
  public static final String PING_JWT_KEY_ID = "apisigningcert";
  public static final String PING_JWS_ALGORITHM = "RS384";
  public static final String PING_JWT_ISSUER = "PingFederate";



  public static final String UNIQUE_DOC_ID_PATH_PARAMETER = "unique-doc-id";
  public static final String UNIQUE_DOC_ID_DYNAMIC_PATH_PARAMETER =
          "{" + UNIQUE_DOC_ID_PATH_PARAMETER + "}";
  public static final String UNIQUE_DOC_ID_REQUIRED_MSG =
          UNIQUE_DOC_ID_PATH_PARAMETER + PATH_PARAMETER_IS_REQUIRED;
  public static final String WB_USER_ID_PATCH_PARAMETER = "wbUserId";
  public static final String WB_USER_ID_PATCH_GREATER_THAN_ZERO_MSG =
          WB_USER_ID_PATCH_PARAMETER + PARAMETER_GREATER_THAN_ZERO;
  public static final String FILTER_QUERY_PARAMETER = "filter";
  public static final String REGEX_ARCHIVE_FILTER_QUERY_PARAMETER = "^(archive:true*$)";
  public static final String INVALID_ARCHIVE_FILTER_REGEX_MESSAGE =
          FILTER_QUERY_PARAMETER
                  + " query parameter does not "
                  + "match the required pattern. Valid value: archive:true";
  public static final String ARCHIVE_FILTER_PATTERN = "archive:";
  public static final String REGEX_CATEGORY_SUBCATEGORY_FILTER_QUERY_PARAMETER =
          "^(category:[1-9](,[1-9])*$)|"
                  + "(subcategory:(1[0-1]|[1-9])(,(1[0-1]|[1-9]))*$)|"
                  + "(archive:true*$)";
  public static final String INVALID_FILTER_REGEX_MESSAGE =
          FILTER_QUERY_PARAMETER
                  + " query parameter does not "
                  + "match the required pattern. Valid examples: "
                  + "filter=category:1 or filter=category:1,2,3 or "
                  + "filter=subcategory:2 or filter=subcategory:1,2,3"
                  + " or filter=archive:true"
                  + "Valid category ids [1-3] and subcategory ids [1-11]";
  public static final String CATEGORY_FILTER_PATTERN = "category:";
  public static final String SUB_CATEGORY_FILTER_PATTERN = "subcategory:";
  public static final String UNIQUE_DOC_ID = "c3VyZXR5LWFnZW5jeS1ib25kLXJlcG8vc3VyZXR5LWFnZW5jeS1ib25kLWRvY3VtZW50L2Y3NGY5MmQxLWQ5ZTYtNDFjOS04ZjYzLWQwNzM3MDlmZDA3Mw==";
  public static final String LOGGER_MESSAGE_STATUS_CODE_AND_MESSAGE = "with http status code {} and a message {}";
  public static final String VERY_LONG_NOTES =
          """
                Java is a general-purpose programming language that is class-based, object-oriented, and designed to have as few implementation dependencies as possible. It is intended to let application developers write once, run anywhere (WORA),[16] meaning that compiled Java code can run on all platforms that support Java without the need for recompilation.[17] Java applications are typically compiled to bytecode that can run on any Java virtual machine (JVM) regardless of the underlying computer architecture. The syntax of Java is similar to C and C++, but it has fewer low-level facilities than either of them. As of 2019, Java was one of the most popular programming languages in use according to GitHub,[18][19] particularly for client-server web applications, with a reported 9 million developers.[20]
    
                Java was originally developed by James Gosling at Sun Microsystems (which has since been acquired by Oracle) and released in 1995 as a core component of Sun Microsystems' Java platform. The original and reference implementation Java compilers, virtual machines, and class libraries were originally released by Sun under proprietary licenses. As of May 2007, in compliance with the specifications of the Java Community Process, Sun had relicensed most of its Java technologies under the GNU General Public License. Meanwhile, others have developed alternative implementations of these Sun technologies, such as the GNU Compiler for Java (bytecode compiler), GNU Classpath (standard libraries), and IcedTea-Web (browser plugin for applets).
    
                The latest versions are Java 14, released in March 2020, and Java 11, a currently supported long-term support (LTS) version, released on September 25, 2018; Oracle released for the legacy Java 8 LTS the last free public update in January 2019 for commercial use, while it will otherwise still support Java 8 with public updates for personal use up to at least December 2020. Oracle (and others) highly recommend uninstalling older versions of Java because of serious risks due to unresolved security issues.[21] Since Java 9, 10, 12 and 13 are no longer supported, Oracle advises its users to immediately transition to the latest version (currently Java 14) or an LTS release""";

  public static final int EXPECTED_SINGLE_ARCHIVE_METADATA = 1;
  public static final int EXPECTED_SINGLE_METADATA = 1;
  public static final int EXPECTED_TWO_METADATA = 2;

  public static final Boolean TEST_IS_NPPI = false;
  public static final String TEST_DOCUMENT_RESIDENCY = null;
  public static final String TEST_PAYMENT_DATE = null;
  public static final String TEST_CHECK_EFT_NUM = null;
  public static final Boolean TEST_REISSUE = null;
  public static final String TEST_SAMPLE_NOTE_1 = "Sample note -1";
  public static final String TEST_SAMPLE_NOTE_4 = "Sample note - 4";
  public static final int MIN_UNIQUE_DOC_ID_LENGTH = 1;

  //LOA related constants
  public static final String LOA_METADATA_BASE_ENDPOINT = "/api/v1/loa/";
  public static final String LOA_ID_PATH_PARAMETER = "loa-id";
  public static final String LOA_ID_DYNAMIC_PATH_PARAMETER =
          "{" + LOA_ID_PATH_PARAMETER + "}";
  public static final String LOA_METADATA_DYNAMODB_TABLE = "grs-loa-document-mgmt-metadata";
  public static final String LOA_ID_REQUIRED_MSG =
          LOA_ID_PATH_PARAMETER + PATH_PARAMETER_IS_REQUIRED;
  public static final String LOA_ID_GREATER_THAN_ZERO_MSG =
          LOA_ID_PATH_PARAMETER + PARAMETER_GREATER_THAN_ZERO;
  public static final String LOA_ID_NOT_VALID_INTEGER_MSG =
          LOA_ID_PATH_PARAMETER + " path parameter is not a valid Integer";
  public static final String LOA_METADATA_DYNAMODB_ARCHIVE_TABLE =
          "grs-loa-document-mgmt-archive-metadata";
  public static final Integer LOCAL_LOA_ID_147853025 = 147853025;
  public static final Integer LOCAL_LOA_ID_286412212 = 286412212;
  public static final Integer LOCAL_LOA_ID_158759469 = 158759469;
  public static final Integer LOCAL_LOA_ID_158759470 = 158759470;
  public static final Integer LOCAL_LOA_ID_587524897 = 587524897;
  public static final Integer LOCAL_LOA_ID_FOR_STORE = 999999998;
  public static final Integer LOCAL_LOA_ID_FOR_RESTORE = 888888888;
  public static final Integer LOCAL_LOA_ID_FOR_RESTORE_2 = 999999999;
  public static final Integer LOCAL_LOA_ID_FOR_ARCHIVE_MAIN_TABLE = 288884888;
  public static final String LOA_MULTIPART_FILE_PARAMETER = "file";
  public static final String ENVOY_REPO = "envoy-repo";

  // OAuth2 Client Registration IDs for Envoy
  public static final String ENVOY_WRITE_CLIENT_REGISTRATION_ID = "envoy-write";
  public static final String ENVOY_READ_CLIENT_REGISTRATION_ID = "envoy-read";

  // Envoy Service Metadata JSON Properties
  public static final String ENVOY_SERVICE_META_LEVEL2_CAT = "level2Cat";
  public static final String ENVOY_SERVICE_META_DATA_OWNING_LOCALE = "dataOwningLocale";
  public static final String ENVOY_SERVICE_META_ORIGINAL_FILE_NAME = "originalFileName";
  public static final String ENVOY_SERVICE_META_LEVEL2_CAT_VALUE = "test";
  public static final String INDIVIDUAL_ID_REQUIRED_MSG = LOA_ID_PATH_PARAMETER + PATH_PARAMETER_IS_REQUIRED;
  public static final String AZURE_TOKEN_CACHE_NAME = "azureTokenCache";
  public static final String TRACKING_ID = "Tracking-Id";
  public static final String INDIVIDUAL_USER_ID_PARAMETER = "INDIVIDUAL-ID";
  public static final String LOCAL_INDIVIDUAL_USER_ID_N1685073 = "n1685073";
}
