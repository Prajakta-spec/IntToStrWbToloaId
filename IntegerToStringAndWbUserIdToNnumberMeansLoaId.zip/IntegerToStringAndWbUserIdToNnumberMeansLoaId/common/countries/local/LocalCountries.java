package com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.countries.local;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.countries.entity.WbCountry;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

@Getter
@Setter
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class LocalCountries {

  private static final Logger LOGGER = LoggerFactory.getLogger(LocalCountries.class);

  @JsonProperty("countries")
  private List<WbCountry> wbCountries;
}
