/*
 * Copyright (C) 2020, Liberty Mutual Group
 *
 * Created on 4/2/20, 11:15 AM
 */

package com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.metadata.store;

import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.BaseLoaIntegrationTest;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.constants.Constants;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.error.LoaDocumentMgmtErrorResponse;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.store.LoaDocumentStoreResponse;
import java.util.Base64;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;


@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.DEFINED_PORT)
@ActiveProfiles({Constants.INTEGRATION_TEST_ENVIRONMENT})
public class LoaStoreContentControllerIT extends BaseLoaIntegrationTest {

    private static final long TEST_LOA_ID = 335414617L;


    @Value("${server.port}")
    private int definedServerPort;

    @Value("classpath:local-documents/file-example_PDF_1MB.pdf")
    private Resource loaDocumentPdfDocument;

    @Value("classpath:documents/GeoEye_GeoEye1_50cm_8bit_RGB_DRA_Mining_2009FEB14_8bits_sub_r_15.jpg")
    private Resource loaLargeImageDocument;

    @Value("classpath:local-documents/empty-file.txt")
    private Resource loaEmptyDocument;

    @Value("classpath:documents/no-extension-file")
    private Resource fileWithoutExtension;

    private static String baseUrl;

    private WebClient webClient;

    @Before
    public void setUp() {
        baseUrl = "http://localhost:" + definedServerPort + Constants.LOA_METADATA_BASE_ENDPOINT;
        webClient = WebClient.builder().baseUrl(baseUrl).build();
    }

    @Test
    public void validateStorePdfDocument() {
        MultiValueMap<String, Object> form = new LinkedMultiValueMap<>();
        form.add(Constants.LOA_MULTIPART_FILE_PARAMETER, loaDocumentPdfDocument);
        form.add(Constants.CATEGORY_ID_PARAMETER, Constants.LOCAL_CATEGORY_SUB_CATEGORY_ID_1);
        form.add(Constants.SUB_CATEGORY_ID_PARAMETER, Constants.LOCAL_CATEGORY_SUB_CATEGORY_ID_1);
        form.add(Constants.RECEIVED_DATE_PARAMETER, "2017-09-16");
        form.add(Constants.NOTES_PARAMETER, "Sample note -1");
        form.add(Constants.NPPI_PARAMETER, false);

        ResponseEntity<LoaDocumentStoreResponse> res =
                webClient.post()
                        .uri("{loaId}/documents", TEST_LOA_ID)
                        .contentType(MediaType.MULTIPART_FORM_DATA)
                        .body(BodyInserters.fromMultipartData(form))
                        .retrieve()
                        .toEntity(LoaDocumentStoreResponse.class)
                        .block();

        Assert.assertNotNull(res);
        Assert.assertNotNull(res.getBody());
        String uniqueDocId = res.getBody().getData().getDocumentStore().getUniqueDocId();
        Assert.assertTrue(uniqueDocId != null && uniqueDocId.length() > 1);
    }

    // ------------------ POSITIVE: store large image ------------------
    @Test
    public void validateStoreLargeImageDocument() {
        MultiValueMap<String, Object> form = new LinkedMultiValueMap<>();
        form.add(Constants.LOA_MULTIPART_FILE_PARAMETER, loaLargeImageDocument);
        form.add(Constants.CATEGORY_ID_PARAMETER, Integer.valueOf(Constants.LOCAL_CATEGORY_SUB_CATEGORY_ID_2));
        form.add(Constants.SUB_CATEGORY_ID_PARAMETER, Constants.LOCAL_CATEGORY_SUB_CATEGORY_ID_5);
        form.add(Constants.RECEIVED_DATE_PARAMETER, "2014-12-31");
        form.add(Constants.NPPI_PARAMETER, true);
        form.add(Constants.WB_USER_ID_PARAMETER, Constants.LOCAL_USER_ID_1822);

        ResponseEntity<LoaDocumentStoreResponse> res =
                webClient.post()
                        .uri("{loaId}/documents", TEST_LOA_ID)
                        .contentType(MediaType.MULTIPART_FORM_DATA)
                        .body(BodyInserters.fromMultipartData(form))
                        .retrieve()
                        .toEntity(LoaDocumentStoreResponse.class)
                        .block();

        Assert.assertNotNull(res);
        String uniqueDocId = res.getBody().getData().getDocumentStore().getUniqueDocId();
        Assert.assertTrue(uniqueDocId != null && uniqueDocId.length() > 1);
    }

    // ------------------ NEGATIVE: file param missing -> 400 ------------------
    @Test
    public void validateFileParameterMissing() {
        MultiValueMap<String, Object> form = new LinkedMultiValueMap<>();
        // no file added intentionally
        form.add(Constants.CATEGORY_ID_PARAMETER, Constants.LOCAL_CATEGORY_SUB_CATEGORY_ID_1);
        form.add(Constants.SUB_CATEGORY_ID_PARAMETER, Constants.LOCAL_CATEGORY_SUB_CATEGORY_ID_1);
        form.add(Constants.RECEIVED_DATE_PARAMETER, "2017-09-16");
        form.add(Constants.NPPI_PARAMETER, false);
        form.add(Constants.WB_USER_ID_PARAMETER, Constants.LOCAL_USER_ID_2053);

        ResponseEntity<LoaDocumentMgmtErrorResponse> res =
                webClient.post()
                        .uri("{loaId}/documents", TEST_LOA_ID)
                        .contentType(MediaType.MULTIPART_FORM_DATA)
                        .body(BodyInserters.fromMultipartData(form))
                        .exchange()
                        .flatMap(r -> r.toEntity(LoaDocumentMgmtErrorResponse.class))
                        .block();

        Assert.assertNotNull(res);
        Assert.assertEquals(HttpStatus.BAD_REQUEST.value(), res.getStatusCodeValue());
    }

    // ------------------ NEGATIVE: category missing -> 400 ------------------
    @Test
    public void validateCategoryIdMissing() {
        MultiValueMap<String, Object> form = new LinkedMultiValueMap<>();
        form.add(Constants.LOA_MULTIPART_FILE_PARAMETER, loaDocumentPdfDocument);
        form.add(Constants.SUB_CATEGORY_ID_PARAMETER, Constants.LOCAL_CATEGORY_SUB_CATEGORY_ID_1);
        form.add(Constants.RECEIVED_DATE_PARAMETER, "2017-09-16");
        form.add(Constants.NPPI_PARAMETER, false);
        form.add(Constants.WB_USER_ID_PARAMETER, Constants.LOCAL_USER_ID_2053);

        ResponseEntity<LoaDocumentMgmtErrorResponse> res =
                webClient.post()
                        .uri("{loaId}/documents", TEST_LOA_ID)
                        .contentType(MediaType.MULTIPART_FORM_DATA)
                        .body(BodyInserters.fromMultipartData(form))
                        .exchange()
                        .flatMap(r -> r.toEntity(LoaDocumentMgmtErrorResponse.class))
                        .block();

        Assert.assertNotNull(res);
        Assert.assertEquals(HttpStatus.BAD_REQUEST.value(), res.getStatusCodeValue());
    }

    // ------------------ NEGATIVE: subcategory missing -> 400 ------------------
    @Test
    public void validateSubCategoryIdMissing() {
        MultiValueMap<String, Object> form = new LinkedMultiValueMap<>();
        form.add(Constants.LOA_MULTIPART_FILE_PARAMETER, loaDocumentPdfDocument);
        form.add(Constants.CATEGORY_ID_PARAMETER, Constants.LOCAL_CATEGORY_SUB_CATEGORY_ID_1);
        form.add(Constants.RECEIVED_DATE_PARAMETER, "2017-09-16");
        form.add(Constants.NPPI_PARAMETER, false);
        form.add(Constants.WB_USER_ID_PARAMETER, Constants.LOCAL_USER_ID_2053);

        ResponseEntity<LoaDocumentMgmtErrorResponse> res =
                webClient.post()
                        .uri("{loaId}/documents", TEST_LOA_ID)
                        .contentType(MediaType.MULTIPART_FORM_DATA)
                        .body(BodyInserters.fromMultipartData(form))
                        .exchange()
                        .flatMap(r -> r.toEntity(LoaDocumentMgmtErrorResponse.class))
                        .block();

        Assert.assertNotNull(res);
        Assert.assertEquals(HttpStatus.BAD_REQUEST.value(), res.getStatusCodeValue());
    }

    // ------------------ POSITIVE: wb user header omitted but allowed ------------------
    @Test
    public void validateHeaderParameterWbUserIdNull() {
        MultiValueMap<String, Object> form = new LinkedMultiValueMap<>();
        form.add(Constants.LOA_MULTIPART_FILE_PARAMETER, loaDocumentPdfDocument);
        form.add(Constants.CATEGORY_ID_PARAMETER, Constants.LOCAL_CATEGORY_SUB_CATEGORY_ID_1);
        form.add(Constants.SUB_CATEGORY_ID_PARAMETER, Constants.LOCAL_CATEGORY_SUB_CATEGORY_ID_1);
        form.add(Constants.RECEIVED_DATE_PARAMETER, "2017-09-16");
        form.add(Constants.NPPI_PARAMETER, false);
        // no WB user id

        ResponseEntity<LoaDocumentStoreResponse> res =
                webClient.post()
                        .uri("{loaId}/documents", TEST_LOA_ID)
                        .contentType(MediaType.MULTIPART_FORM_DATA)
                        .body(BodyInserters.fromMultipartData(form))
                        .retrieve()
                        .toEntity(LoaDocumentStoreResponse.class)
                        .block();

        Assert.assertNotNull(res);
        Assert.assertTrue(res.getBody().getData().getDocumentStore().getUniqueDocId().length() > 1);
    }

    // ------------------ NEGATIVE: wb user id as "null" string -> 400 ------------------
    @Test
    public void validateWbUserIdNullString() {
        MultiValueMap<String, Object> form = new LinkedMultiValueMap<>();
        form.add(Constants.LOA_MULTIPART_FILE_PARAMETER, loaDocumentPdfDocument);
        form.add(Constants.CATEGORY_ID_PARAMETER, Constants.LOCAL_CATEGORY_SUB_CATEGORY_ID_1);
        form.add(Constants.SUB_CATEGORY_ID_PARAMETER, Integer.valueOf(Constants.LOCAL_CATEGORY_SUB_CATEGORY_ID_3));
        form.add(Constants.RECEIVED_DATE_PARAMETER, "2017-09-16");
        form.add(Constants.WB_USER_ID_PARAMETER, "\"null\"");

        ResponseEntity<LoaDocumentMgmtErrorResponse> res =
                webClient.post()
                        .uri("{loaId}/documents", TEST_LOA_ID)
                        .contentType(MediaType.MULTIPART_FORM_DATA)
                        .body(BodyInserters.fromMultipartData(form))
                        .exchange()
                        .flatMap(r -> r.toEntity(LoaDocumentMgmtErrorResponse.class))
                        .block();

        Assert.assertNotNull(res);
        Assert.assertEquals(HttpStatus.BAD_REQUEST.value(), res.getStatusCodeValue());
    }

    // ------------------ NEGATIVE: wb user id empty spaces -> 400 ------------------
    @Test
    public void validateWbUserIdEmptyString() {
        MultiValueMap<String, Object> form = new LinkedMultiValueMap<>();
        form.add(Constants.LOA_MULTIPART_FILE_PARAMETER, loaDocumentPdfDocument);
        form.add(Constants.CATEGORY_ID_PARAMETER, Constants.LOCAL_CATEGORY_SUB_CATEGORY_ID_1);
        form.add(Constants.SUB_CATEGORY_ID_PARAMETER, Integer.valueOf(Constants.LOCAL_CATEGORY_SUB_CATEGORY_ID_3));
        form.add(Constants.RECEIVED_DATE_PARAMETER, "2017-09-16");
        form.add(Constants.WB_USER_ID_PARAMETER, "\"  \"");

        ResponseEntity<LoaDocumentMgmtErrorResponse> res =
                webClient.post()
                        .uri("{loaId}/documents", TEST_LOA_ID)
                        .contentType(MediaType.MULTIPART_FORM_DATA)
                        .body(BodyInserters.fromMultipartData(form))
                        .exchange()
                        .flatMap(r -> r.toEntity(LoaDocumentMgmtErrorResponse.class))
                        .block();

        Assert.assertNotNull(res);
        Assert.assertEquals(HttpStatus.BAD_REQUEST.value(), res.getStatusCodeValue());
    }

    // ------------------ NEGATIVE: received date missing -> 400 ------------------
    @Test
    public void validateReceivedDateMissing() {
        MultiValueMap<String, Object> form = new LinkedMultiValueMap<>();
        form.add(Constants.LOA_MULTIPART_FILE_PARAMETER, loaDocumentPdfDocument);
        form.add(Constants.CATEGORY_ID_PARAMETER, Constants.LOCAL_CATEGORY_SUB_CATEGORY_ID_1);
        form.add(Constants.SUB_CATEGORY_ID_PARAMETER, Constants.LOCAL_CATEGORY_SUB_CATEGORY_ID_1);
        // missing received date
        form.add(Constants.WB_USER_ID_PARAMETER, Constants.LOCAL_USER_ID_2053);

        ResponseEntity<LoaDocumentMgmtErrorResponse> res =
                webClient.post()
                        .uri("{loaId}/documents", TEST_LOA_ID)
                        .contentType(MediaType.MULTIPART_FORM_DATA)
                        .body(BodyInserters.fromMultipartData(form))
                        .exchange()
                        .flatMap(r -> r.toEntity(LoaDocumentMgmtErrorResponse.class))
                        .block();

        Assert.assertNotNull(res);
        Assert.assertEquals(HttpStatus.BAD_REQUEST.value(), res.getStatusCodeValue());
    }

    // ------------------ NEGATIVE: empty file -> 400 ------------------
    @Test
    public void validateEmptyFile() {
        MultiValueMap<String, Object> form = new LinkedMultiValueMap<>();
        form.add(Constants.LOA_MULTIPART_FILE_PARAMETER, loaEmptyDocument);
        form.add(Constants.CATEGORY_ID_PARAMETER, Constants.LOCAL_CATEGORY_SUB_CATEGORY_ID_1);
        form.add(Constants.SUB_CATEGORY_ID_PARAMETER, Constants.LOCAL_CATEGORY_SUB_CATEGORY_ID_1);
        form.add(Constants.RECEIVED_DATE_PARAMETER, "2017-09-16");
        form.add(Constants.WB_USER_ID_PARAMETER, Constants.LOCAL_USER_ID_2053);

        ResponseEntity<LoaDocumentMgmtErrorResponse> res =
                webClient.post()
                        .uri("{loaId}/documents", TEST_LOA_ID)
                        .contentType(MediaType.MULTIPART_FORM_DATA)
                        .body(BodyInserters.fromMultipartData(form))
                        .exchange()
                        .flatMap(r -> r.toEntity(LoaDocumentMgmtErrorResponse.class))
                        .block();

        Assert.assertNotNull(res);
        Assert.assertEquals(HttpStatus.BAD_REQUEST.value(), res.getStatusCodeValue());
    }

    // ------------------ NEGATIVE: file without extension -> 400 ------------------
    @Test
    public void validateFileWithoutExtension() {
        MultiValueMap<String, Object> form = new LinkedMultiValueMap<>();
        form.add(Constants.LOA_MULTIPART_FILE_PARAMETER, fileWithoutExtension);
        form.add(Constants.CATEGORY_ID_PARAMETER, Constants.LOCAL_CATEGORY_SUB_CATEGORY_ID_1);
        form.add(Constants.SUB_CATEGORY_ID_PARAMETER, Constants.LOCAL_CATEGORY_SUB_CATEGORY_ID_1);
        form.add(Constants.RECEIVED_DATE_PARAMETER, "2017-09-16");
        form.add(Constants.WB_USER_ID_PARAMETER, Constants.LOCAL_USER_ID_2053);

        ResponseEntity<LoaDocumentMgmtErrorResponse> res =
                webClient.post()
                        .uri("{loaId}/documents", TEST_LOA_ID)
                        .contentType(MediaType.MULTIPART_FORM_DATA)
                        .body(BodyInserters.fromMultipartData(form))
                        .exchange()
                        .flatMap(r -> r.toEntity(LoaDocumentMgmtErrorResponse.class))
                        .block();

        Assert.assertNotNull(res);
        Assert.assertEquals(HttpStatus.BAD_REQUEST.value(), res.getStatusCodeValue());
    }

    // ------------------ POSITIVE: residency attribute accepted ------------------
    @Test
    public void validateStorePdfDocumentWithValidDocumentResidency() {
        MultiValueMap<String, Object> form = new LinkedMultiValueMap<>();
        form.add(Constants.LOA_MULTIPART_FILE_PARAMETER, loaDocumentPdfDocument);
        form.add(Constants.CATEGORY_ID_PARAMETER, Constants.LOCAL_CATEGORY_SUB_CATEGORY_ID_1);
        form.add(Constants.SUB_CATEGORY_ID_PARAMETER, Constants.LOCAL_CATEGORY_SUB_CATEGORY_ID_1);
        form.add(Constants.RECEIVED_DATE_PARAMETER, "2017-09-16");
        form.add(Constants.NPPI_PARAMETER, false);
        form.add(Constants.DOCUMENT_RESIDENCY_PARAMETER, "CAN");

        ResponseEntity<LoaDocumentStoreResponse> res =
                webClient.post()
                        .uri("{loaId}/documents", TEST_LOA_ID)
                        .contentType(MediaType.MULTIPART_FORM_DATA)
                        .body(BodyInserters.fromMultipartData(form))
                        .retrieve()
                        .toEntity(LoaDocumentStoreResponse.class)
                        .block();

        Assert.assertNotNull(res);
        Assert.assertTrue(res.getBody().getData().getDocumentStore().getUniqueDocId().length() > 1);
    }

    // ------------------ NEGATIVE: unsupported residency -> 400 ------------------
    @Test
    public void validateStorePdfDocumentWithNotSupportedDocumentResidency() {
        MultiValueMap<String, Object> form = new LinkedMultiValueMap<>();
        form.add(Constants.LOA_MULTIPART_FILE_PARAMETER, loaDocumentPdfDocument);
        form.add(Constants.CATEGORY_ID_PARAMETER, Constants.LOCAL_CATEGORY_SUB_CATEGORY_ID_1);
        form.add(Constants.SUB_CATEGORY_ID_PARAMETER, Constants.LOCAL_CATEGORY_SUB_CATEGORY_ID_1);
        form.add(Constants.RECEIVED_DATE_PARAMETER, "2017-09-16");
        form.add(Constants.NPPI_PARAMETER, false);
        form.add(Constants.DOCUMENT_RESIDENCY_PARAMETER, "UAE");

        ResponseEntity<LoaDocumentMgmtErrorResponse> res =
                webClient.post()
                        .uri("{loaId}/documents", TEST_LOA_ID)
                        .contentType(MediaType.MULTIPART_FORM_DATA)
                        .body(BodyInserters.fromMultipartData(form))
                        .exchange()
                        .flatMap(r -> r.toEntity(LoaDocumentMgmtErrorResponse.class))
                        .block();

        Assert.assertNotNull(res);
        Assert.assertEquals(HttpStatus.BAD_REQUEST.value(), res.getStatusCodeValue());
    }

    // ------------------ NEGATIVE: invalid residency code length -> 400 ------------------
    @Test
    public void validateStorePdfDocumentWithInvalidDocumentResidencyLongISOCode() {
        MultiValueMap<String, Object> form = new LinkedMultiValueMap<>();
        form.add(Constants.LOA_MULTIPART_FILE_PARAMETER, loaDocumentPdfDocument);
        form.add(Constants.CATEGORY_ID_PARAMETER, Constants.LOCAL_CATEGORY_SUB_CATEGORY_ID_1);
        form.add(Constants.SUB_CATEGORY_ID_PARAMETER, Constants.LOCAL_CATEGORY_SUB_CATEGORY_ID_1);
        form.add(Constants.RECEIVED_DATE_PARAMETER, "2017-09-16");
        form.add(Constants.NPPI_PARAMETER, false);
        form.add(Constants.DOCUMENT_RESIDENCY_PARAMETER, "A123");

        ResponseEntity<LoaDocumentMgmtErrorResponse> res =
                webClient.post()
                        .uri("{loaId}/documents", TEST_LOA_ID)
                        .contentType(MediaType.MULTIPART_FORM_DATA)
                        .body(BodyInserters.fromMultipartData(form))
                        .exchange()
                        .flatMap(r -> r.toEntity(LoaDocumentMgmtErrorResponse.class))
                        .block();

        Assert.assertNotNull(res);
        Assert.assertEquals(HttpStatus.BAD_REQUEST.value(), res.getStatusCodeValue());
    }

    // ------------------ NEGATIVE: invalid residency code -> 400 ------------------
    @Test
    public void validateStorePdfDocumentWithInvalidDocumentResidency() {
        MultiValueMap<String, Object> form = new LinkedMultiValueMap<>();
        form.add(Constants.LOA_MULTIPART_FILE_PARAMETER, loaDocumentPdfDocument);
        form.add(Constants.CATEGORY_ID_PARAMETER, Constants.LOCAL_CATEGORY_SUB_CATEGORY_ID_1);
        form.add(Constants.SUB_CATEGORY_ID_PARAMETER, Constants.LOCAL_CATEGORY_SUB_CATEGORY_ID_1);
        form.add(Constants.RECEIVED_DATE_PARAMETER, "2017-09-16");
        form.add(Constants.NPPI_PARAMETER, false);
        form.add(Constants.DOCUMENT_RESIDENCY_PARAMETER, "ABC");

        ResponseEntity<LoaDocumentMgmtErrorResponse> res =
                webClient.post()
                        .uri("{loaId}/documents", TEST_LOA_ID)
                        .contentType(MediaType.MULTIPART_FORM_DATA)
                        .body(BodyInserters.fromMultipartData(form))
                        .exchange()
                        .flatMap(r -> r.toEntity(LoaDocumentMgmtErrorResponse.class))
                        .block();

        Assert.assertNotNull(res);
        Assert.assertEquals(HttpStatus.BAD_REQUEST.value(), res.getStatusCodeValue());
    }

    // ------------------ POSITIVE: commission statements attributes allowed ------------------
    @Test
    public void validateCommissionStatementsSubCategoryWithRightAttributes() {
        MultiValueMap<String, Object> form = new LinkedMultiValueMap<>();
        form.add(Constants.LOA_MULTIPART_FILE_PARAMETER, loaDocumentPdfDocument);
        form.add(Constants.CATEGORY_ID_PARAMETER, Constants.LOCAL_CATEGORY_SUB_CATEGORY_ID_5);
        form.add(Constants.SUB_CATEGORY_ID_PARAMETER, Constants.LOCAL_CATEGORY_SUB_CATEGORY_ID_11);
        form.add(Constants.RECEIVED_DATE_PARAMETER, "2017-09-16");
        form.add(Constants.CHECK_EFT_NUM_PARAMETER, "123456");
        form.add(Constants.REISSUE_PARAMETER, true);

        ResponseEntity<LoaDocumentStoreResponse> res =
                webClient.post()
                        .uri("{loaId}/documents", TEST_LOA_ID)
                        .contentType(MediaType.MULTIPART_FORM_DATA)
                        .body(BodyInserters.fromMultipartData(form))
                        .retrieve()
                        .toEntity(LoaDocumentStoreResponse.class)
                        .block();

        Assert.assertNotNull(res);
        Assert.assertTrue(res.getBody().getData().getDocumentStore().getUniqueDocId().length() > 1);
    }

    // ------------------ NEGATIVE: unsupported attribute+subcategory combo -> 400 ------------------
    @Test
    public void validateStoreDocumentWithNotSupportedAttributeAndSubCategoryCombination() {
        MultiValueMap<String, Object> form = new LinkedMultiValueMap<>();
        form.add(Constants.LOA_MULTIPART_FILE_PARAMETER, loaDocumentPdfDocument);
        form.add(Constants.CATEGORY_ID_PARAMETER, Constants.LOCAL_CATEGORY_SUB_CATEGORY_ID_1);
        form.add(Constants.SUB_CATEGORY_ID_PARAMETER, Constants.LOCAL_CATEGORY_SUB_CATEGORY_ID_1);
        form.add(Constants.RECEIVED_DATE_PARAMETER, "2017-09-16");
        form.add(Constants.DOCUMENT_RESIDENCY_PARAMETER, "USA");
        form.add(Constants.CHECK_EFT_NUM_PARAMETER, "123456");
        form.add(Constants.REISSUE_PARAMETER, true);

        ResponseEntity<LoaDocumentMgmtErrorResponse> res =
                webClient.post()
                        .uri("{loaId}/documents", TEST_LOA_ID)
                        .contentType(MediaType.MULTIPART_FORM_DATA)
                        .body(BodyInserters.fromMultipartData(form))
                        .exchange()
                        .flatMap(r -> r.toEntity(LoaDocumentMgmtErrorResponse.class))
                        .block();

        Assert.assertNotNull(res);
        Assert.assertEquals(HttpStatus.BAD_REQUEST.value(), res.getStatusCodeValue());
    }

    // ------------------ POSITIVE: repo mapping assertions (Base64 decode uniqueId) ------------------
    @Test
    public void validateCommissionStatementDocumentsStoredInBillingRepository() {
        MultiValueMap<String, Object> form = new LinkedMultiValueMap<>();
        form.add(Constants.LOA_MULTIPART_FILE_PARAMETER, loaDocumentPdfDocument);
        form.add(Constants.CATEGORY_ID_PARAMETER, Integer.valueOf(Constants.LOCAL_CATEGORY_SUB_CATEGORY_ID_4));
        form.add(Constants.SUB_CATEGORY_ID_PARAMETER, Constants.LOCAL_CATEGORY_SUB_CATEGORY_ID_10);
        form.add(Constants.RECEIVED_DATE_PARAMETER, "2019-12-23");

        ResponseEntity<LoaDocumentStoreResponse> res =
                webClient.post()
                        .uri("{loaId}/documents", TEST_LOA_ID)
                        .contentType(MediaType.MULTIPART_FORM_DATA)
                        .body(BodyInserters.fromMultipartData(form))
                        .retrieve()
                        .toEntity(LoaDocumentStoreResponse.class)
                        .block();

        Assert.assertNotNull(res);
        String uniqueDocId = res.getBody().getData().getDocumentStore().getUniqueDocId();
        String repoName = new String(Base64.getDecoder().decode(uniqueDocId)).split("[/]")[1];
        Assert.assertEquals("surety-loa-document", repoName);
    }

    @Test
    public void validateNonBillingDocumentsStoredInLoaRepository() {
        MultiValueMap<String, Object> form = new LinkedMultiValueMap<>();
        form.add(Constants.LOA_MULTIPART_FILE_PARAMETER, loaDocumentPdfDocument);
        form.add(Constants.CATEGORY_ID_PARAMETER, Constants.LOCAL_CATEGORY_SUB_CATEGORY_ID_1);
        form.add(Constants.SUB_CATEGORY_ID_PARAMETER, Constants.LOCAL_CATEGORY_SUB_CATEGORY_ID_1);
        form.add(Constants.RECEIVED_DATE_PARAMETER, "2017-09-16");

        ResponseEntity<LoaDocumentStoreResponse> res =
                webClient.post()
                        .uri("{loaId}/documents", TEST_LOA_ID)
                        .contentType(MediaType.MULTIPART_FORM_DATA)
                        .body(BodyInserters.fromMultipartData(form))
                        .retrieve()
                        .toEntity(LoaDocumentStoreResponse.class)
                        .block();

        Assert.assertNotNull(res);
        String uniqueDocId = res.getBody().getData().getDocumentStore().getUniqueDocId();
        String repoName = new String(Base64.getDecoder().decode(uniqueDocId)).split("[/]")[1];
        Assert.assertEquals("surety-loa-document", repoName);
    }

}
