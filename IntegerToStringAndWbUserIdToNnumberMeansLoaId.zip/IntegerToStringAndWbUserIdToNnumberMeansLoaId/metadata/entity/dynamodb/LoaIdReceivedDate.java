package com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.dynamodb;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBIndexRangeKey;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.Date;

@Getter
@Setter
@ToString
public class LoaIdReceivedDate extends LoaId {

  @DynamoDBIndexRangeKey(
      globalSecondaryIndexName = "idx_global_individual_id_order_received_date",
      attributeName = "received_date")
  private Date receivedDate;
}
