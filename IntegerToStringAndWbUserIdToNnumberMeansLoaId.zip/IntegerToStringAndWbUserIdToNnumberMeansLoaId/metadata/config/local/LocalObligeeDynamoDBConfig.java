package com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.config.local;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.AWSCredentialsProvider;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.client.builder.AwsClientBuilder;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBAsync;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBAsyncClientBuilder;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapperConfig;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTypeConverterFactory;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.constants.Constants;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Profile;

@Configuration
@Profile({
  Constants.LOCAL_ENVIRONMENT,
  Constants.LOCAL_DOCKER_ENVIRONMENT,
  Constants.INTEGRATION_TEST_ENVIRONMENT
})
public class LocalObligeeDynamoDBConfig {
  @Value("${aws.individual.credentials.accessKey}")
  private String amazonAWSAccessKey;

  @Value("${aws.individual.credentials.secretKey}")
  private String amazonAWSSecretKey;

  @Value("${individual.dynamodb.endpoint}")
  private String dynamoDBEndpoint;

  @Value("${aws.region.static}")
  private String awsRegion;

  @Value("${dynamodb.environment.prefix}")
  private String dynamoDBEnvironmentTablePrefix;

  public AWSCredentialsProvider amazonAWSCredentialsProvider() {
    return new AWSStaticCredentialsProvider(amazonAWSCredentials());
  }

  @Bean
  public AWSCredentials amazonAWSCredentials() {
    return new BasicAWSCredentials(amazonAWSAccessKey, amazonAWSSecretKey);
  }

  public AwsClientBuilder.EndpointConfiguration setDynamoDBEndpointConfiguration() {
    return new AwsClientBuilder.EndpointConfiguration(dynamoDBEndpoint, awsRegion);
  }

  @Bean("amazonDynamoDB")
  public AmazonDynamoDBAsync amazonDynamoDB() {
    return AmazonDynamoDBAsyncClientBuilder.standard()
        .withCredentials(amazonAWSCredentialsProvider())
        .withEndpointConfiguration(setDynamoDBEndpointConfiguration())
        .build();
  }

  @Primary
  @Bean("dynamoDBMapper")
  public DynamoDBMapper dynamoDBMapper(
      AmazonDynamoDB amazonDynamoDB, DynamoDBMapperConfig dynamoDBMapperConfig) {
    return new DynamoDBMapper(amazonDynamoDB, dynamoDBMapperConfig);
  }

  @Bean("dynamoDBMapperConfig")
  public DynamoDBMapperConfig dynamoDBMapperConfig() {
    return new DynamoDBMapperConfig.Builder()
        .withTableNameOverride(
            DynamoDBMapperConfig.TableNameOverride.withTableNamePrefix(
                dynamoDBEnvironmentTablePrefix))
        .withTypeConverterFactory(DynamoDBTypeConverterFactory.standard())
        .build();
  }
}

