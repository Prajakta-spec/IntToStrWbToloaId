package com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.config;

import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.constants.Constants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.security.oauth2.client.OAuth2AuthorizedClientManager;
import org.springframework.security.oauth2.client.web.reactive.function.client.ServletOAuth2AuthorizedClientExchangeFilterFunction;
import org.springframework.web.reactive.function.client.WebClient;

/**
 * Configuration class for creating WebClient beans with OAuth2 authentication for Envoy services.
 * Provides separate WebClient instances for read and write operations with appropriate OAuth2 client registrations.
 */
@Configuration
@Profile({
    Constants.LOCAL_ENVIRONMENT,
    Constants.DEVELOPMENT_ENVIRONMENT,
    Constants.TEST_ENVIRONMENT,
    Constants.STAGING_ENVIRONMENT,
    Constants.PRODUCTION_ENVIRONMENT
})
public class EnvoyAPIWebClient {

    @Value("${envoy.api.header.public-key.value}")
    private String envoyPublicKey;

    /**
     * Creates a WebClient bean configured for Envoy write operations.
     * Uses the envoy-write OAuth2 client registration for authentication.
     *
     * @param authorizedClientManager the OAuth2 authorized client manager (optional)
     * @return configured WebClient for write operations
     */
    @Bean(value = "envoyWriteWebClient")
    public WebClient getEnvoyWebClient(
            @Autowired(required = false) OAuth2AuthorizedClientManager authorizedClientManager) {

        WebClient.Builder builder = WebClient.builder();

        // Configure OAuth2 for write operations
        if (authorizedClientManager != null) {
            ServletOAuth2AuthorizedClientExchangeFilterFunction oauth2Client =
                    new ServletOAuth2AuthorizedClientExchangeFilterFunction(authorizedClientManager);
            oauth2Client.setDefaultClientRegistrationId(Constants.ENVOY_WRITE_CLIENT_REGISTRATION_ID);
            builder.apply(oauth2Client.oauth2Configuration());
        }

        // Add default headers including Public-Key and Content-Type for write operations
        return builder
                .defaultHeader("Public-Key", envoyPublicKey)
                .defaultHeader("Content-Type", "application/octet-stream")
                .build();
    }

    /**
     * Creates a WebClient bean configured for Envoy read operations.
     * Uses the envoy-read OAuth2 client registration for authentication.
     *
     * @param authorizedClientManager the OAuth2 authorized client manager (optional)
     * @return configured WebClient for read operations
     */
    @Bean(value = "envoyReadWebClient")
    public WebClient getEnvoyReadWebClient(
            @Autowired(required = false) OAuth2AuthorizedClientManager authorizedClientManager) {

        WebClient.Builder builder = WebClient.builder();

        if (authorizedClientManager != null) {
            ServletOAuth2AuthorizedClientExchangeFilterFunction oauth2Client =
                    new ServletOAuth2AuthorizedClientExchangeFilterFunction(authorizedClientManager);
            oauth2Client.setDefaultClientRegistrationId(Constants.ENVOY_READ_CLIENT_REGISTRATION_ID);
            builder.apply(oauth2Client.oauth2Configuration());
        }

        // Add default headers including Public-Key
        return builder
                .defaultHeader("Public-Key", envoyPublicKey)
                .build();
    }
}
