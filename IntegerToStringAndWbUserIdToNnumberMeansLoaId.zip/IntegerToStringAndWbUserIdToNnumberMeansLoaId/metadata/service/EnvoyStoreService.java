package com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.service;


import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.constants.Constants;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.store.EnvoyStoreResponse;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.exception.EnvoyClientException;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.exception.EnvoyServerException;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;

import java.net.URI;
import java.util.Objects;

@Service
public class EnvoyStoreService {

  private static final Logger LOGGER = LoggerFactory.getLogger(EnvoyStoreService.class);

  private final WebClient envoyWebClient;

  @Value("${envoy.store.content.api.endpoint}")
  private String envoyStoreEndpoint;

  public EnvoyStoreService(@Qualifier("envoyWriteWebClient") WebClient envoyWebClient) {
    this.envoyWebClient = envoyWebClient;
  }

  public EnvoyStoreResponse uploadLoaDocuments(
      MultipartFile loaMultiPartFile,
      String individualId,
      String documentResidency,
      String trackingId)
      throws JSONException, EnvoyClientException, EnvoyServerException {
    LOGGER.info("{} - Enter EnvoyStoreService.uploadLoaDocuments()", trackingId);
    ResponseEntity<EnvoyStoreResponse> envoyStoreResponseEntity;

    JSONObject loaServiceMeta = new JSONObject();
    // this must be replaced with loaId
    loaServiceMeta.put(Constants.ENVOY_SERVICE_META_LEVEL2_CAT, Constants.ENVOY_SERVICE_META_LEVEL2_CAT_VALUE);
    loaServiceMeta.put(Constants.ENVOY_SERVICE_META_DATA_OWNING_LOCALE, documentResidency);
    loaServiceMeta.put(Constants.ENVOY_SERVICE_META_ORIGINAL_FILE_NAME, loaMultiPartFile.getOriginalFilename());
    LOGGER.info("{} - serviceMetadata sent to Envoy:  {} ", trackingId, loaServiceMeta);

    try {
      envoyStoreResponseEntity = envoyWebClient.post()
              .uri(envoyStoreEndpoint)
              .header(Constants.ENVOY_SERVICE_META_HEADER, loaServiceMeta.toString())
              .body(BodyInserters.fromResource(loaMultiPartFile.getResource()))
              .retrieve()
              .toEntity(EnvoyStoreResponse.class)
              .block();
    } catch (HttpClientErrorException httpClientErrorException) {
      LOGGER.error(
          "{} - Envoy Store API {}/{} threw a HttpClientErrorException with the http status code: {} "
              + "and a body {}",
          trackingId,
          envoyStoreEndpoint,
              individualId,
          httpClientErrorException.getStatusCode(),
          httpClientErrorException.getResponseBodyAsByteArray());
      throw new EnvoyClientException(
          HttpStatus.valueOf(httpClientErrorException.getStatusCode().value()),
          httpClientErrorException.getResponseBodyAsString());
    } catch (HttpServerErrorException httpServerErrorException) {
      LOGGER.error(
          "{} - Envoy Store API {}/{} threw a HttpServerErrorException with the http status code: {} "
              + "and a body {}",
          trackingId,
          envoyStoreEndpoint,
              individualId,
          httpServerErrorException.getStatusCode(),
          httpServerErrorException.getResponseBodyAsString());
      throw new EnvoyServerException(
          HttpStatus.valueOf(httpServerErrorException.getStatusCode().value()),
          httpServerErrorException.getResponseBodyAsString());
    }
    LOGGER.info("{} - Exit EnvoyStoreService.uploadLoaDocuments()", trackingId);
    return envoyStoreResponseEntity.getBody();
  }
}