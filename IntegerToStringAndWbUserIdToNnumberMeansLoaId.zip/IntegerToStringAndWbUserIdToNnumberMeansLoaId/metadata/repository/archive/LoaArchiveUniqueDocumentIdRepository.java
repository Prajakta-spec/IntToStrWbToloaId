package com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.repository.archive;

import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.dynamodb.LoaArchiveMetadata;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.PagingAndSortingRepository;

public interface LoaArchiveUniqueDocumentIdRepository
    extends PagingAndSortingRepository<LoaArchiveMetadata, String>,
        CrudRepository<LoaArchiveMetadata, String> {}