package com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.repository.archive;

import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.dynamodb.LoaArchiveMetadata;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.dynamodb.LoaId;
import org.springframework.data.repository.PagingAndSortingRepository;

import java.util.List;

public interface LoaIdArchiveRepository
    extends PagingAndSortingRepository<LoaArchiveMetadata, LoaId> {

  List<LoaArchiveMetadata> findAllByLoaId(String loaId);
}