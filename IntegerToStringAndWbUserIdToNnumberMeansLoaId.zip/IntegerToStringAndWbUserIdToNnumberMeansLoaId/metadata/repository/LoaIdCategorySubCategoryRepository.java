package com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.repository;

import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.dynamodb.LoaMetadata;

import java.util.List;

public interface LoaIdCategorySubCategoryRepository {

  List<LoaMetadata> findByLoaIdAndCategoryIds(String loaId, List<Integer> categoryIds);

  List<LoaMetadata> findByLoaIdAndSubCategoryIds(String loaId, List<Integer> subCategoryIds);
}