package com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.controller;

import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.RequestTracker;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.constants.Constants;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.delete.LoaDocumentArchiveSuccessResponse;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.delete.LoaDocumentDeleteResponse;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.delete.LoaDocumentDeleteSuccessResponseData;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.dynamodb.LoaMetadata;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.error.LoaDocumentMgmtErrorResponse;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.exception.DocumentsNotFoundException;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.exception.InvalidIndividualIdException;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.repository.LoaUniqueDocumentIdRepository;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.repository.archive.LoaArchiveUniqueDocumentIdRepository;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.service.LoaMetadataService;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.service.archive.LoaArchiveMetadataService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.validation.constraints.Pattern;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@Validated
@RequestMapping(
    path = Constants.LOA_METADATA_BASE_ENDPOINT,
    produces = MediaType.APPLICATION_JSON_VALUE)
public class LoaArchiveDocumentsController {
  private static final Logger LOGGER =
      LoggerFactory.getLogger(LoaArchiveDocumentsController.class);

  private final RequestTracker requestTracker;

  private final LoaUniqueDocumentIdRepository loaUniqueDocumentIdRepository;

  private final LoaArchiveMetadataService loaArchiveMetadataService;

  private final LoaMetadataService loaMetadataService;

  private final LoaArchiveUniqueDocumentIdRepository loaArchiveUniqueDocumentIdRepository;

  public LoaArchiveDocumentsController(
      RequestTracker requestTracker,
      LoaUniqueDocumentIdRepository loaUniqueDocumentIdRepository,
      LoaArchiveMetadataService loaArchiveMetadataService,
      LoaMetadataService loaMetadataService,
      LoaArchiveUniqueDocumentIdRepository loaArchiveUniqueDocumentIdRepository) {
    this.requestTracker = requestTracker;
    this.loaUniqueDocumentIdRepository = loaUniqueDocumentIdRepository;
    this.loaArchiveMetadataService = loaArchiveMetadataService;
    this.loaMetadataService = loaMetadataService;
    this.loaArchiveUniqueDocumentIdRepository = loaArchiveUniqueDocumentIdRepository;
  }

  @DeleteMapping(
      path =
          Constants.LOA_ID_DYNAMIC_PATH_PARAMETER
              + "/documents/"
              + Constants.UNIQUE_DOC_ID_DYNAMIC_PATH_PARAMETER)
  @Operation(
      summary = "Delete loa document by uniqueDocId",
      description = "Delete a loa document by loaId and uniqueDocId",
      method = "DELETE",
      tags = {"Loa Archive Document Content"})
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            description = "Loa Archive Document",
            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
        @ApiResponse(
            responseCode = "400",
            description = "Bad Request",
            content =
                @Content(
                    mediaType = MediaType.APPLICATION_JSON_VALUE,
                    schema = @Schema(implementation = LoaDocumentMgmtErrorResponse.class))),
        @ApiResponse(
            responseCode = "403",
            description = "Not Authorized to access loa document management API",
            content =
                @Content(
                    mediaType = MediaType.APPLICATION_JSON_VALUE,
                    schema = @Schema(implementation = LoaDocumentMgmtErrorResponse.class))),
        @ApiResponse(
            responseCode = "404",
            description = "Document not found",
            content =
                @Content(
                    mediaType = MediaType.APPLICATION_JSON_VALUE,
                    schema = @Schema(implementation = LoaDocumentMgmtErrorResponse.class))),
        @ApiResponse(
            responseCode = "500",
            description = "Internal Server Error",
            content =
                @Content(
                    mediaType = MediaType.APPLICATION_JSON_VALUE,
                    schema = @Schema(implementation = LoaDocumentMgmtErrorResponse.class)))
      })
  public ResponseEntity<LoaDocumentDeleteResponse> deleteDocumentContentByUniqueDocId(
          @PathVariable(value = Constants.LOA_ID_PATH_PARAMETER)
          String loaId,
          @PathVariable(value = Constants.UNIQUE_DOC_ID_PATH_PARAMETER) String uniqueDocId,
          @Parameter(name = Constants.INDIVIDUAL_USER_ID_PARAMETER, example = "N1685073")
          @RequestHeader(value = Constants.INDIVIDUAL_USER_ID_PARAMETER, required = false)
          @Pattern(message = Constants.INDIVIDUAL_USER_ID_PARAMETER, regexp = "^[A-Za-z0-9]+$") String individualId)
      throws DocumentsNotFoundException, InvalidIndividualIdException {
    String trackingId = requestTracker.getTrackingId();
    LOGGER.info(
        "{} - Enter LoaArchiveDocumentsController.deleteDocumentContentByUniqueDocId()"
            + " - loaId: {} and uniqueDocId: {}",
        trackingId,
        loaId,
        uniqueDocId);

    HttpStatus httpStatus = HttpStatus.OK;
    Optional<LoaMetadata> loaMetadataOptional =
        loaUniqueDocumentIdRepository.findById(uniqueDocId);
    LoaDocumentDeleteResponse loaDocumentDeleteResponse =
        new LoaDocumentDeleteResponse();
    LoaDocumentDeleteSuccessResponseData loaDocumentDeleteSuccessResponseData;
    if (loaMetadataOptional.isPresent()) {
      LoaMetadata loaMetadata = loaMetadataOptional.get();
      if (loaId.equals(loaMetadata.getLoaId())) {
        loaDocumentDeleteSuccessResponseData = new LoaDocumentDeleteSuccessResponseData();
        LoaDocumentArchiveSuccessResponse loaDocumentArchiveSuccessResponse =
            new LoaDocumentArchiveSuccessResponse();
        String verifiedIndividualId = null;
        if (individualId == null) {
          verifiedIndividualId = loaMetadataService.returnDefaultIndividualIdIfIndividualIdNull();
        } else if (loaMetadataService.isValidIndividualId(individualId)) {
          verifiedIndividualId = individualId;
        }
        if (verifiedIndividualId != null) {
          loaArchiveUniqueDocumentIdRepository.save(
              loaArchiveMetadataService.createLoaArchiveMetadata(
                      loaMetadata, verifiedIndividualId));

          LOGGER.info(
              "{} - Saving document in loa archive table trackingId: and loaId: {}",
              trackingId,
              loaId);
          loaUniqueDocumentIdRepository.delete(loaMetadata);
          LOGGER.info(
              "{} - deleting document {} from loa metadata table trackingId: and loaId {}",
              loaMetadata.getDocumentName(),
              trackingId,
              loaId);
          loaDocumentArchiveSuccessResponse.setMessage(
              loaMetadata.getDocumentName()
                  + " document of loaId:"
                  + loaMetadata.getLoaId()
                  + " deleted successfully");
        }
        loaDocumentDeleteResponse.setTrackingId(trackingId);
        loaDocumentDeleteResponse.setData(loaDocumentDeleteSuccessResponseData);
        loaDocumentDeleteSuccessResponseData.setDocumentArchive(
                loaDocumentArchiveSuccessResponse);
      } else {
        LOGGER.error(
            "{} - DocumentsNotFoundException: No documents found for uniqueDocId: {} and loaId: {}",
            trackingId,
            uniqueDocId,
            loaId);
        throw new DocumentsNotFoundException(
            HttpStatus.NOT_FOUND,
            "No documents found for uniqueDocId: " + uniqueDocId + " and loaId: " + loaId);
      }
    } else {
      LOGGER.error(
          "{} - DocumentsNotFoundException: No documents found for uniqueDocId: {} and loaId: {}",
          trackingId,
          uniqueDocId,
          loaId);
      throw new DocumentsNotFoundException(
          HttpStatus.NOT_FOUND,
          "No documents found for uniqueDocId: " + uniqueDocId + " and loaId: " + loaId);
    }

    LOGGER.info(
        "{} - Exit LoaArchiveDocumentsController.deleteDocumentContentByUniqueDocId()",
        trackingId);
    return new ResponseEntity<>(loaDocumentDeleteResponse, httpStatus);
  }
}