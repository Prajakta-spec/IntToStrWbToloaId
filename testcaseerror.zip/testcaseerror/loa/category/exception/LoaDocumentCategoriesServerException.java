package com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.category.exception;

import lombok.Getter;
import lombok.Setter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;

@Getter
@Setter
public class LoaDocumentCategoriesServerException extends Exception {

  private static final Logger logger =
      LoggerFactory.getLogger(LoaDocumentCategoriesServerException.class);

  private final HttpStatus httpStatusCode;

  public LoaDocumentCategoriesServerException(HttpStatus httpStatusCode, String message) {
    super(message);
    this.httpStatusCode = httpStatusCode;
  }
}