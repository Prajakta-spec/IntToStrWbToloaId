package com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.controller;

import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.RequestTracker;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.constants.Constants;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.category.exception.LoaDocumentCategoriesClientException;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.category.exception.LoaDocumentCategoriesServerException;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.dynamodb.LoaMetadata;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.error.LoaDocumentMgmtErrorResponse;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.metadata.StoreMetadataResponse;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.store.LoaStoreMetadata;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.exception.DocumentMetadataAlreadyExistException;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.exception.InvalidCategorySubCategoryException;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.exception.InvalidDocumentException;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.exception.InvalidIndividualIdException;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.mapper.LoaMetadataMapper;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.repository.LoaUniqueDocumentIdRepository;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.service.LoaMetadataService;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.validation.LoaMetadataValidator;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@Validated
@RequestMapping(
    path = Constants.LOA_METADATA_BASE_ENDPOINT,
    produces = MediaType.APPLICATION_JSON_VALUE)
@Slf4j
public class LoaMetadataController {
  private final RequestTracker requestTracker;
  private final LoaUniqueDocumentIdRepository loaUniqueDocumentIdRepository;
  private final LoaMetadataService loaMetadataService;
  private final LoaMetadataValidator loaMetadataValidator;
  private final LoaMetadataMapper loaMetadataMapper;

  public LoaMetadataController(
      RequestTracker requestTracker,
      LoaUniqueDocumentIdRepository loaUniqueDocumentIdRepository,
      LoaMetadataService loaMetadataService,
      LoaMetadataValidator loaMetadataValidator,
      LoaMetadataMapper loaMetadataMapper) {
    this.requestTracker = requestTracker;
    this.loaUniqueDocumentIdRepository = loaUniqueDocumentIdRepository;
    this.loaMetadataService = loaMetadataService;
    this.loaMetadataValidator = loaMetadataValidator;
    this.loaMetadataMapper = loaMetadataMapper;
  }

  @PostMapping(
      path = Constants.LOA_ID_DYNAMIC_PATH_PARAMETER + Constants.DOCUMENT_METADATA_PATH,
      consumes = MediaType.APPLICATION_JSON_VALUE)
  @Operation(
      summary = "Store Document Metadata",
      description = "Store Document Metadata By UniqueDocId",
      method = "POST",
      tags = {"Store New Document Metadata"})
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            description = "Store Document Metadata",
            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
        @ApiResponse(
            responseCode = "400",
            description = "Bad Request",
            content =
                @Content(
                    mediaType = MediaType.APPLICATION_JSON_VALUE,
                    schema = @Schema(implementation = LoaDocumentMgmtErrorResponse.class))),
        @ApiResponse(
            responseCode = "403",
            description = "Not Authorized to access loa document management API",
            content =
                @Content(
                    mediaType = MediaType.APPLICATION_JSON_VALUE,
                    schema = @Schema(implementation = LoaDocumentMgmtErrorResponse.class))),
        @ApiResponse(
            responseCode = "404",
            description = "Document Metadata Not Found",
            content =
                @Content(
                    mediaType = MediaType.APPLICATION_JSON_VALUE,
                    schema = @Schema(implementation = LoaDocumentMgmtErrorResponse.class))),
        @ApiResponse(
            responseCode = "500",
            description = "Internal Server Error",
            content =
                @Content(
                    mediaType = MediaType.APPLICATION_JSON_VALUE,
                    schema = @Schema(implementation = LoaDocumentMgmtErrorResponse.class)))
      })
  public ResponseEntity<StoreMetadataResponse> storeLoaMetadata(
      @RequestBody @Valid LoaStoreMetadata loaStoreMetadata,
      @PathVariable(value = Constants.LOA_ID_PATH_PARAMETER)
          @NotNull(message = Constants.LOA_ID_REQUIRED_MSG)
      @Pattern(message = Constants.INDIVIDUAL_USER_ID_PARAMETER, regexp = "^[A-Za-z0-9]+$") String loaId)
      throws InvalidDocumentException,
          InvalidIndividualIdException,
          LoaDocumentCategoriesServerException,
          LoaDocumentCategoriesClientException,
          InvalidCategorySubCategoryException,
          DocumentMetadataAlreadyExistException {

    String trackingId = requestTracker.getTrackingId();
    log.info("{} - Begin handling request to store new document metadata", trackingId);

    loaMetadataValidator.validate(loaStoreMetadata, trackingId);

    if (loaStoreMetadata.getCreatedById() == null) {
      String verifiedWbUserId = loaMetadataService.returnDefaultIndividualIdIfIndividualIdNull();
      log.info(
          "{} - createdById was null setting to default value {}", trackingId, verifiedWbUserId);
      loaStoreMetadata.setCreatedById(verifiedWbUserId);
    }

    LoaMetadata loaMetadata =
        loaMetadataMapper.loaStoreMetadataToLoaMetadata(loaStoreMetadata, loaId);
    LoaMetadata savedLoaMetadata = loaUniqueDocumentIdRepository.save(loaMetadata);

    StoreMetadataResponse storeMetadataResponse = new StoreMetadataResponse();
    storeMetadataResponse.setTrackingId(trackingId);
    storeMetadataResponse.setMessage(
        "Document metadata saved successfully for loa id: "
            + savedLoaMetadata.getLoaId()
            + " with the uniqueDocId: "
            + savedLoaMetadata.getUniqueDocId());

    log.info(
        "{} - Exit LoaStoreMetadataController.storeLoaMetadata(). Document metadata saved successfully for loa id: {} with the uniqueDocId:{};",
        trackingId,
        savedLoaMetadata.getLoaId(),
        savedLoaMetadata.getUniqueDocId());
    return new ResponseEntity<>(storeMetadataResponse, HttpStatus.OK);
  }
}