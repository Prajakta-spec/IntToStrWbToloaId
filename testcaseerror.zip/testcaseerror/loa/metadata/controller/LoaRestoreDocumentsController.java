package com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.controller;

import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.RequestTracker;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.constants.Constants;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.dynamodb.LoaArchiveMetadata;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.error.LoaDocumentMgmtErrorResponse;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.restore.LoaDocumentRestoreResponse;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.restore.LoaDocumentRestoreSuccessResponse;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.restore.LoaDocumentRestoreSuccessResponseData;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.exception.DocumentsNotFoundException;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.repository.LoaUniqueDocumentIdRepository;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.repository.archive.LoaArchiveUniqueDocumentIdRepository;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.service.restore.LoaRestoreMetadataService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.validation.constraints.Pattern;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Optional;

@RestController
@Validated
@RequestMapping(path = Constants.LOA_METADATA_BASE_ENDPOINT, produces = MediaType.APPLICATION_JSON_VALUE)
public class LoaRestoreDocumentsController {

    private static final Logger LOGGER = LoggerFactory.getLogger(LoaRestoreDocumentsController.class);

    private final RequestTracker requestTracker;

    private final LoaUniqueDocumentIdRepository loaUniqueDocumentIdRepository;

    private final LoaRestoreMetadataService loaRestoreMetadataService;

    private final LoaArchiveUniqueDocumentIdRepository loaArchiveUniqueDocumentIdRepository;

    public LoaRestoreDocumentsController(RequestTracker requestTracker,
                                         LoaUniqueDocumentIdRepository loaUniqueDocumentIdRepository,
                                         LoaRestoreMetadataService loaRestoreMetadataService,
                                         LoaArchiveUniqueDocumentIdRepository loaArchiveUniqueDocumentIdRepository) {
        this.requestTracker = requestTracker;
        this.loaUniqueDocumentIdRepository = loaUniqueDocumentIdRepository;
        this.loaRestoreMetadataService = loaRestoreMetadataService;
        this.loaArchiveUniqueDocumentIdRepository = loaArchiveUniqueDocumentIdRepository;
    }

    @PostMapping(path = Constants.LOA_ID_DYNAMIC_PATH_PARAMETER + "/documents/" +
            Constants.UNIQUE_DOC_ID_DYNAMIC_PATH_PARAMETER + "/restore")
    @Operation(summary = "Restore loa document by uniqueDocId",
            description = "Restore an loa document by loaId and uniqueDocId",
            method = "POST", tags = {"Loa Restore Document Content"})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200",
                    description = "Loa Restore Document",
                    content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "400", description = "Bad Request",
                    content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                            schema = @Schema(implementation = LoaDocumentMgmtErrorResponse.class))),
            @ApiResponse(responseCode = "403",
                    description = "Not Authorized to access loa document management API",
                    content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                            schema = @Schema(implementation = LoaDocumentMgmtErrorResponse.class))),
            @ApiResponse(responseCode = "404", description = "Document not found",
                    content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                            schema = @Schema(implementation = LoaDocumentMgmtErrorResponse.class))),
            @ApiResponse(responseCode = "500", description = "Internal Server Error",
                    content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                            schema = @Schema(implementation = LoaDocumentMgmtErrorResponse.class)))
    })
    public ResponseEntity<LoaDocumentRestoreResponse> restoreDocumentContentByUniqueDocId(
            @PathVariable(value = Constants.LOA_ID_PATH_PARAMETER)
            @Pattern(message = Constants.INDIVIDUAL_USER_ID_PARAMETER, regexp = "^[A-Za-z0-9]+$") String loaId,
            @PathVariable(value = Constants.UNIQUE_DOC_ID_PATH_PARAMETER)
                    String uniqueDocId) throws DocumentsNotFoundException {

        String trackingId = requestTracker.getTrackingId();
        LOGGER.info("{} - Enter LoaRestoreDocumentsController.restoreDocumentContentByUniqueDocId()" +
                " - loaId: {} and uniqueDocId: {}", trackingId, loaId, uniqueDocId);
        HttpStatus httpStatus = HttpStatus.OK;
        Optional<LoaArchiveMetadata> loaArchiveMetadataOptional = loaArchiveUniqueDocumentIdRepository.findById(uniqueDocId);
        LoaDocumentRestoreResponse loaDocumentRestoreResponse = new LoaDocumentRestoreResponse();
        LoaDocumentRestoreSuccessResponseData loaDocumentRestoreSuccessResponseData;
        if (loaArchiveMetadataOptional.isPresent()) {
            LoaArchiveMetadata loaArchiveMetadata = loaArchiveMetadataOptional.get();
            if (loaId.equals(loaArchiveMetadata.getLoaId())) {
                loaDocumentRestoreSuccessResponseData = new LoaDocumentRestoreSuccessResponseData();
                LoaDocumentRestoreSuccessResponse loaDocumentRestoreSuccessResponse = new LoaDocumentRestoreSuccessResponse();
                loaUniqueDocumentIdRepository.save(loaRestoreMetadataService.restoreLoaMetadata(loaArchiveMetadata));
                LOGGER.info("{} - Saving document in loa metadata table trackingId: and loaId: {}", trackingId, loaId);
                loaArchiveUniqueDocumentIdRepository.delete(loaArchiveMetadata);
                LOGGER.info("{} - deleting document {} from loa archive table trackingId: and loaId: {}", loaArchiveMetadata.getDocumentName(), trackingId, loaId);
                loaDocumentRestoreSuccessResponse.setMessage(loaArchiveMetadata.getDocumentName() + " for loaId: "
                        + loaArchiveMetadata.getLoaId() + " was restored successfully and the uniqueDocId is: " + uniqueDocId);
                loaDocumentRestoreResponse.setTrackingId(trackingId);
                loaDocumentRestoreSuccessResponseData.setLoaDocumentRestoreSuccessResponse(loaDocumentRestoreSuccessResponse);
                loaDocumentRestoreResponse.setData(loaDocumentRestoreSuccessResponseData);
            } else {
                LOGGER.error("{} - DocumentsNotFoundException: No documents found for uniqueDocId: {} and loaId: {}",
                        trackingId, uniqueDocId, loaId);
                throw new DocumentsNotFoundException(HttpStatus.NOT_FOUND,
                        "No documents found for uniqueDocId: " + uniqueDocId + " and loaId: " + loaId);
            }
        } else {
            LOGGER.error("{} - DocumentsNotFoundException: No documents found for uniqueDocId: {} and loaId: {}",
                    trackingId, uniqueDocId, loaId);
            throw new DocumentsNotFoundException(HttpStatus.NOT_FOUND,
                    "No documents found for uniqueDocId: " + uniqueDocId + " and loaId: " + loaId);
        }
        LOGGER.info("{} - Exit LoaRestoreDocumentsController.restoreDocumentContentByUniqueDocId()", trackingId);
        return new ResponseEntity <>(loaDocumentRestoreResponse, httpStatus);

    }
}
