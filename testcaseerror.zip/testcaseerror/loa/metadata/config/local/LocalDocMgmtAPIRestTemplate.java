package com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.config.local;

import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.constants.Constants;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.web.client.RestTemplate;

@Configuration
@Profile({
  Constants.LOCAL_ENVIRONMENT,
  Constants.LOCAL_DOCKER_ENVIRONMENT,
  Constants.INTEGRATION_TEST_ENVIRONMENT
})
public class LocalDocMgmtAPIRestTemplate {

  @Bean("localDocMgmtRestTemplate")
  public RestTemplate envoyRestTemplate(RestTemplateBuilder restTemplateBuilder) {
    return restTemplateBuilder.build();
  }
}