package com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.repository;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBQueryExpression;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.dynamodb.LoaMetadata;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class LoaIdReceivedDateRepositoryImpl implements LoaIdCategorySubCategoryRepository {

  private final DynamoDBMapper dynamoDBMapper;

  public LoaIdReceivedDateRepositoryImpl(DynamoDBMapper dynamoDBMapper) {
    this.dynamoDBMapper = dynamoDBMapper;
  }

  @Override
  public List<LoaMetadata> findByLoaIdAndCategoryIds(String loaId, List<Integer> categoryIds) {
    return executeQueryToFilterByCategoryOrSubCategoryIds(true, loaId, categoryIds);
  }

  @Override
  public List<LoaMetadata> findByLoaIdAndSubCategoryIds(String loaId, List<Integer> subCategoryIds) {
    return executeQueryToFilterByCategoryOrSubCategoryIds(false, loaId, subCategoryIds);
  }

  private List<LoaMetadata> executeQueryToFilterByCategoryOrSubCategoryIds(
      boolean isCategoryFilter, String loaId, List<Integer> categoryOrSubCategoryIds) {
    String filterAttributeName;
    if (isCategoryFilter) {
      filterAttributeName = "category_id";
    } else {
      filterAttributeName = "sub_category_id";
    }

    DynamoDBQueryExpression<LoaMetadata> dynamoDBQueryExpression = new DynamoDBQueryExpression<>();

    Map<String, AttributeValue> expressionAttributeValues = new HashMap<>();
    expressionAttributeValues.put(":loaId", new AttributeValue().withS(loaId));

    List<String> idList = new ArrayList<>();
    for (int i = 0; i < categoryOrSubCategoryIds.size(); i++) {
      idList.add(":id" + (i + 1));
      expressionAttributeValues.put(
          ":id" + (i + 1),
          new AttributeValue().withN(String.valueOf(categoryOrSubCategoryIds.get(i))));
    }

    dynamoDBQueryExpression
        .withIndexName("idx_global_individual_id_order_received_date")
        .withKeyConditionExpression("individual_id = :loaId")
        .withFilterExpression(filterAttributeName + " IN (" + String.join(",", idList) + ")")
        .withScanIndexForward(false)
        .withConsistentRead(false)
        .withExpressionAttributeValues(expressionAttributeValues);

    return dynamoDBMapper.query(LoaMetadata.class, dynamoDBQueryExpression);
  }
}
