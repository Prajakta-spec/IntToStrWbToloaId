package com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.error;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.IOException;
import java.util.List;

public class ErrorResponseDataDeserializer extends JsonDeserializer<ErrorResponseData> {
    @Override
    public ErrorResponseData deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
        JsonNode node = p.getCodec().readTree(p);
        ErrorResponseData data = new ErrorResponseData();
        if (node.isTextual()) {
            Error error = new Error();
            error.setMessage(node.asText());
            data.setErrors(List.of(error));
        } else if (node.has("errors")) {
            ObjectMapper mapper = (ObjectMapper) p.getCodec();
            List<Error> errors = mapper.convertValue(node.get("errors"),
                    mapper.getTypeFactory().constructCollectionType(List.class, Error.class));
            data.setErrors(errors);
        }
        return data;
    }

}