package com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.retreive;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.dynamodb.LoaArchiveMetadata;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.dynamodb.LoaMetadata;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

@Getter
@Setter
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class LoaDocumentMetadataSuccessResponseData {

  @JsonProperty("documentMetadata")
  private List<LoaMetadata> loaMetadata;

  @JsonProperty("documentArchiveMetadata")
  private List<LoaArchiveMetadata> loaArchiveMetadata;
}