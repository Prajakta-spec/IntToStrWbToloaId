package com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.service;


import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.RequestTracker;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.graph.validation.UserValidator;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.category.entity.LoaDocumentCategoriesResponse;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.category.entity.LoaDocumentCategory;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.category.entity.LoaDocumentSubCategory;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.constants.Constants;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.wbusers.entity.WbUser;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.wbusers.repository.WbUsersRepository;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.exception.InvalidIndividualIdException;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.category.service.LoaDocumentCategoriesService;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.dynamodb.LoaMetadata;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.category.exception.LoaDocumentCategoriesServerException;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.category.exception.LoaDocumentCategoriesClientException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@Service
@Slf4j
public class LoaMetadataService {
  private static final String[] INVALID_FILE_NAME_CHARACTERS = {
    "\\", "/", ":", "*", "\"", "<", ">", "|"
  };

  private final LoaDocumentCategoriesService loaDocumentCategoriesService;

  private final WbUsersRepository wbUsersRepository;

  private final RequestTracker requestTracker;

  private UserValidator userValidator;

  @Value("${document.management.default-wb-user}")
  private String documentManagementDefaultWbUser;

  public LoaMetadataService(
      LoaDocumentCategoriesService loaDocumentCategoriesService,
      WbUsersRepository wbUsersRepository,
      RequestTracker requestTracker, UserValidator userValidator) {
    this.loaDocumentCategoriesService = loaDocumentCategoriesService;
    this.wbUsersRepository = wbUsersRepository;
    this.requestTracker = requestTracker;
    this.userValidator = userValidator;
  }

  public LoaMetadata createLoaMetadata(
      String uniqueDocId,
      String loaId,
      Integer categoryId,
      Integer subCategoryId,
      String createdById,
      String updatedById,
      String receivedDate,
      String paymentDate,
      String documentName,
      String documentExtension,
      Double fileSizeInBytes,
      String notes,
      String checkEftNum,
      Boolean nppi,
      Boolean reissue) {
    LoaMetadata loaMetadata = new LoaMetadata();
    loaMetadata.setUniqueDocId(uniqueDocId);
    loaMetadata.setLoaId(loaId);
    loaMetadata.setCategoryId(categoryId);
    loaMetadata.setSubCategoryId(subCategoryId);
    loaMetadata.setCreatedById(createdById);
    loaMetadata.setUpdatedById(updatedById);
    loaMetadata.setReceivedDate(receivedDate);
    loaMetadata.setDocumentName(documentName);
    loaMetadata.setDocumentExtension(documentExtension);
    loaMetadata.setDocumentSizeInBytes(fileSizeInBytes);
    if (paymentDate != null) {
      loaMetadata.setPaymentDate(paymentDate);
    }
    if (notes != null) {
      loaMetadata.setNotes(notes);
    }
    if (checkEftNum != null) {
      loaMetadata.setCheckEftNum(checkEftNum);
    }
    if (nppi != null) {
      loaMetadata.setNppi(nppi);
    }
    if (reissue != null) {
      loaMetadata.setReissue(reissue);
    }
    loaMetadata.setCreatedAt(new Date());
    loaMetadata.setUpdatedAt(new Date());
    return loaMetadata;
  }

  public boolean isValidCategorySubCategoryCombination(
      Integer categoryId, Integer subCategoryId, String opaqueBearerToken)
      throws LoaDocumentCategoriesServerException, LoaDocumentCategoriesClientException {
    boolean isValidCategorySubCategoryCombination = false;
    LoaDocumentCategoriesResponse loaDocumentCategoriesResponse =
        loaDocumentCategoriesService.getDocumentCategories(opaqueBearerToken);
    if (loaDocumentCategoriesResponse != null
        && loaDocumentCategoriesResponse.getData() != null
        && loaDocumentCategoriesResponse.getData().getDocumentCategories() != null) {
      List<LoaDocumentCategory> loaDocumentCategoryList =
          loaDocumentCategoriesResponse.getData().getDocumentCategories();
      for (LoaDocumentCategory loaDocumentCategory : loaDocumentCategoryList) {
        if (loaDocumentCategory.getDocumentCategoryId().equals(categoryId)) {
          List<LoaDocumentSubCategory> loaDocumentSubCategoryList =
              loaDocumentCategory.getDocumentSubCategories();
          for (LoaDocumentSubCategory loaDocumentSubCategory :
              loaDocumentSubCategoryList) {
            if (loaDocumentSubCategory.getDocumentSubCategoryId().equals(subCategoryId)) {
              isValidCategorySubCategoryCombination = true;
              break;
            }
          }
        }
      }
    }
    return isValidCategorySubCategoryCombination;
  }

  public boolean isValidCategorySubCategoryCombination(Integer categoryId, Integer subCategoryId)
      throws LoaDocumentCategoriesServerException, LoaDocumentCategoriesClientException {
    return this.isValidCategorySubCategoryCombination(
        categoryId, subCategoryId, requestTracker.getOpaqueBearerToken());
  }

  public boolean isInvalidDocumentName(String documentName) {
    return Arrays.stream(INVALID_FILE_NAME_CHARACTERS).parallel().anyMatch(documentName::contains);
  }

  public boolean hasNoExtension(String documentName) {
    return documentName.lastIndexOf('.') < 0;
  }

  public String returnDefaultIndividualIdIfIndividualIdNull() throws InvalidIndividualIdException {
    String trackingId = requestTracker.getTrackingId();
    String individualId;
    if (getDefaultDocMgmtIndividualId(documentManagementDefaultWbUser) != null) {
      individualId = getDefaultDocMgmtIndividualId(documentManagementDefaultWbUser);
      log.info(
          "{} - {} is null. Setting to documentManagementDefaultServiceUserId value",
          trackingId,
          Constants.INDIVIDUAL_USER_ID_PARAMETER);
    } else {
      log.error("{} - Doc mgmt default user does not exist in cached Admin data", trackingId);
      throw new InvalidIndividualIdException(
          HttpStatus.INTERNAL_SERVER_ERROR,
          "  Doc mgmt default user does not exist in cached Admin data");
    }
    return individualId;
  }

  public boolean isValidIndividualId(String individualId) throws InvalidIndividualIdException {
    String trackingId = requestTracker.getTrackingId();
    if(individualId!=null && Boolean.TRUE.equals(userValidator.validateUser(individualId).block())) {
      return true;
    } else {
      log.error("{} - InvalidIndividualIdException: {} is not a valid user id", trackingId, individualId);
      throw new InvalidIndividualIdException(
          HttpStatus.BAD_REQUEST,
          Constants.INDIVIDUAL_USER_ID_PARAMETER + " " + individualId + " is not a valid user id in WB");
    }
  }

  //TODO: Update this method to read n-number from token
  private String getDefaultDocMgmtIndividualId(String nNumber) {
    String individualId = null;
    Optional<WbUser> optionalWbUser = wbUsersRepository.findBynnumber(nNumber);
    if (optionalWbUser.isPresent()) {
      Integer defaultWbUser = optionalWbUser.get().getId();
      if (defaultWbUser != null) {
        individualId = defaultWbUser.toString();
      }
    }
    return individualId;
  }
}
