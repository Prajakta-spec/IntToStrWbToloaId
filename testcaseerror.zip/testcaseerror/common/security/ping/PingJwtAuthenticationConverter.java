package com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.security.ping;

import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.convert.converter.Converter;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.oauth2.jwt.Jwt;

import java.util.stream.Collectors;

@Slf4j
@Configuration
public class PingJwtAuthenticationConverter implements Converter<Jwt, PingToken> {

  @Override
  public PingToken convert(final Jwt jwt) {
    log.trace("JWT - {}. Headers - {}", jwt.getClaims(), jwt.getHeaders());
    return new PingToken(
        jwt.getClaimAsStringList("scope").stream()
            .map(String::toLowerCase)
            .map(
                scope -> {
                  log.debug("Granting Authority to {}", scope);
                  log.info("*************User authenticating using PING**************");
                  return new SimpleGrantedAuthority(scope);
                })
            .collect(Collectors.toList()),
        jwt);
  }
}