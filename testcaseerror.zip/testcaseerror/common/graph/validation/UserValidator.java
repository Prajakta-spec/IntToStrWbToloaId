package com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.graph.validation;


import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.graph.service.UserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

/**
 * Component for validating user existence and related operations.
 */
@Slf4j
@Component
public class UserValidator {

    private final UserService userService;

    public UserValidator(UserService userService) {
        this.userService = userService;
    }

    /**
     * Validates if a user exists by checking with the UserService.
     *
     * @param userCode the user code to validate
     * @return Mono<Boolean> true if user is found, false if not found
     */
    public Mono<Boolean> validateUser(String userCode) {
        log.debug("Validating user existence for userCode: {}", userCode);

        return userService.getUser(userCode)
                .map(userDetail -> {
                    log.debug("User found: {}", userDetail.employeeId());
                    return true;
                })
                .doOnError(error -> log.warn("Error occurred while validating user {}: {}", userCode, error.getMessage()))
                .onErrorReturn(false)
                .defaultIfEmpty(false);
    }
}
