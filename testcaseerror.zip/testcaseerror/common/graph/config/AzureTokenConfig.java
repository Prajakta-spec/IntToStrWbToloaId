package com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.graph.config;

import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.constants.Constants;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.graph.response.AzureTokenResponse;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

@Configuration
public class AzureTokenConfig {

    private final WebClient azureWebClient;

    @Value("${microsoft.azure.client-id}")
    private String clientId;

    @Value("${microsoft.azure.client-secret}")
    private String clientSecret;

    @Value("${microsoft.azure.scope}")
    private String scope;

    private static final String TOKEN_URI = "/v2.0/token";

    public AzureTokenConfig(@Qualifier("azureWebClient") final WebClient azureClient) {
        this.azureWebClient = azureClient;
    }

    @Cacheable(value = Constants.AZURE_TOKEN_CACHE_NAME, unless = "#result == null")
    public Mono<String> requestAzureToken() {
        return this.azureWebClient.post()
                .uri(TOKEN_URI)
                .body(
                        BodyInserters.fromFormData("grant_type", "client_credentials")
                                .with("client_id", this.clientId)
                                .with("client_secret", this.clientSecret)
                                .with("scope", this.scope)
                )
                .retrieve()
                .bodyToMono(AzureTokenResponse.class)
                .map(AzureTokenResponse::access_token);
    }
}
