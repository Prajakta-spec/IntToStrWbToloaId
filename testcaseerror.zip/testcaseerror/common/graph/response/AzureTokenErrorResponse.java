package com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.graph.response;

import java.util.List;

public record AzureTokenErrorResponse(
    String error,
    String error_description,
    List<Integer> error_codes,
    String timestamp,
    String trace_id,
    String correlation_id,
    String error_uri
) {}
