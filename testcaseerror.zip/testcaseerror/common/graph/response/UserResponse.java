package com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.graph.response;

import java.util.List;

public record UserResponse(List<UserDetail> value) {
    public record UserDetail(
        String displayName,
        String givenName,
        String surname,
        String mail,
        String employeeId,
        String jobTitle
    ) {}
}
