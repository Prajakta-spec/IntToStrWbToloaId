package com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.graph.error;

/**
 * Represents an error detail with message and error code.
 * Used for mapping error responses from external services.
 *
 * @param message the error message
 * @param code the error code
 */
public record ErrorDetail(String message, String code) {}
