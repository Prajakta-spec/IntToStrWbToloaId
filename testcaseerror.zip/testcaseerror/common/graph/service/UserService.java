package com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.graph.service;

import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.graph.config.AzureTokenConfig;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.graph.response.UserResponse;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.server.ResponseStatusException;
import reactor.core.publisher.Mono;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

@Service
public class UserService {
    private static final int MAX_GRAPH_API_USERS = 15;
    private final WebClient graphAPIWebClient;
    private final AzureTokenConfig azureTokenService;

    private static final String USER_URI =
            "/v1.0/users?$filter=employeeId in ('%s') " + "&$select=displayName,givenName,surname,mail,employeeId,jobTitle";

    public UserService(
            @Qualifier("graphApiWebClient") final WebClient graphWebClient,
            final AzureTokenConfig azureTokenSvc
    ) {
        this.graphAPIWebClient = graphWebClient;
        this.azureTokenService = azureTokenSvc;
    }

    @Cacheable(value = "userCache", key = "#userCode", unless = "#result == null")
    public Mono<UserResponse.UserDetail> getUser(final String userCode) {
        Mono<UserResponse> userResponse = getUsers(List.of(userCode));

        return userResponse.map(response -> response.value().getFirst());
    }

    @Cacheable(value = "userCache", key = "#userCodes", unless = "#result == null")
    public Mono<UserResponse> getUsers(final List<String> userCodes) {
        if (userCodes.size() > MAX_GRAPH_API_USERS) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Exceeded maximum number of users");
        }

        List<String> validUserCodes = new ArrayList<>();
        final Pattern nNumberPattern = Pattern.compile("^[nNtT]\\d{7}$");

        for (String userCode : userCodes) {
            if (userCode != null && !userCode.isEmpty() && nNumberPattern.matcher(userCode).find()) {
                validUserCodes.add(userCode);
            }
        }

        if (validUserCodes.isEmpty()) {
            return Mono.empty();
        }

        final String uriUserCodes = String.join("','", validUserCodes);

        return azureTokenService
                .requestAzureToken()
                .flatMap(token ->
                        this.graphAPIWebClient.get()
                                .uri(String.format(USER_URI, uriUserCodes))
                                .header(HttpHeaders.AUTHORIZATION, "Bearer " + token)
                                .retrieve()
                                .bodyToMono(UserResponse.class)
                                .flatMap(userResponse -> {
                                    if (userResponse == null || userResponse.value() == null || userResponse.value().isEmpty()) {
                                        return Mono.empty();
                                    }
                                    return Mono.just(userResponse);
                                }));
    }
}
