package com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.countries.repository;

import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.countries.entity.WbCountry;
import org.springframework.data.repository.CrudRepository;

import java.util.Optional;

public interface CountriesRepository extends CrudRepository<WbCountry, Integer> {

  Optional<WbCountry> findByCode(String countryCode);
}