/*
 * Copyright (C) 2020, Liberty Mutual Group
 *
 * Created on 4/2/20, 11:15 AM
 */

package com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.metadata.delete;

import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.BaseLoaIntegrationTest;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.constants.Constants;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.delete.LoaDocumentDeleteResponse;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.error.LoaDocumentMgmtErrorResponse;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.store.LoaDocumentStoreResponse;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.core.io.Resource;
import org.springframework.http.*;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;


@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.DEFINED_PORT)
@ActiveProfiles({Constants.INTEGRATION_TEST_ENVIRONMENT})
public class LoaArchiveDocumentsControllerIT extends BaseLoaIntegrationTest {

    @Value("${server.port}")
    private int definedServerPort;

    @Value("classpath:local-documents/file-example_PDF_1MB.pdf")
    private Resource loaDocumentPdfDocument;

    private static String baseUrl;

    @Autowired
    private TestRestTemplate testRestTemplate;

    @Before
    public void setUp() {
        baseUrl = "http://localhost:" + definedServerPort + Constants.LOA_METADATA_BASE_ENDPOINT;
    }

    @Test
    public void validateDeletedDocumentMetadataWithUniqueID() {
        ResponseEntity<LoaDocumentStoreResponse> loaDocumentStoreResponse =
                testRestTemplate.exchange(baseUrl + "286412844/documents", HttpMethod.POST,
                        prepareMetadataForDocuments(loaDocumentPdfDocument,
                                Constants.LOCAL_CATEGORY_SUB_CATEGORY_ID_1, Constants.LOCAL_CATEGORY_SUB_CATEGORY_ID_1,
                                Constants.LOCAL_USER_ID_FOR_DELETE_ARCHIVE, "2017-09-16", "Sample note -1", false,
                                null,null,null,null),
                        LoaDocumentStoreResponse.class);

        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set(Constants.LOA_ID_PATH_PARAMETER, String.valueOf(Constants.LOCAL_USER_ID_FOR_DELETE_ARCHIVE));
        HttpEntity<Void> httpEntity = new HttpEntity<>(httpHeaders);

        Assert.assertNotNull(loaDocumentStoreResponse);
        Assert.assertNotNull(loaDocumentStoreResponse.getBody());
        Assert.assertNotNull(loaDocumentStoreResponse.getBody().getData());
        Assert.assertNotNull(loaDocumentStoreResponse.getBody().getData().getDocumentStore());
        Assert.assertNotNull(loaDocumentStoreResponse.getBody().getData().getDocumentStore().getUniqueDocId());
        Assert.assertTrue(loaDocumentStoreResponse.getBody().getData().getDocumentStore().getUniqueDocId().length() > 1);

        String uniqueDocId = loaDocumentStoreResponse.getBody().getData().getDocumentStore().getUniqueDocId();
        ResponseEntity <LoaDocumentDeleteResponse> loaDocumentDeleteResponse =
                testRestTemplate.exchange(baseUrl + "286412844/documents/" + uniqueDocId, HttpMethod.DELETE,
                        httpEntity, LoaDocumentDeleteResponse.class);

        Assert.assertNotNull(loaDocumentDeleteResponse);
        Assert.assertNotNull(loaDocumentDeleteResponse.getBody());
        Assert.assertNotNull(loaDocumentDeleteResponse.getBody().getData());
        Assert.assertNotNull(loaDocumentDeleteResponse.getBody().getData().getDocumentArchive());
        Assert.assertEquals("file-example_PDF_1MB.pdf" + " document of loaId:"
                + "286412844" + " deleted successfully", loaDocumentDeleteResponse.getBody().getData().getDocumentArchive().getMessage());
    }

    @Test
    public void validateDeleteDocumentMetadataWhenUserIDisZero() {
        ResponseEntity <LoaDocumentStoreResponse> loaDocumentStoreResponse =
                testRestTemplate.exchange(baseUrl + "286412844/documents", HttpMethod.POST,
                        prepareMetadataForDocuments(loaDocumentPdfDocument,
                                Constants.LOCAL_CATEGORY_SUB_CATEGORY_ID_1, Constants.LOCAL_CATEGORY_SUB_CATEGORY_ID_1,
                                Constants.LOCAL_USER_ID_FOR_DELETE_ARCHIVE, "2017-09-16", "Sample note -1", false,
                                null,null,null,null),
                        LoaDocumentStoreResponse.class);

        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set(Constants.LOA_ID_PATH_PARAMETER, "0");
        HttpEntity<Void> httpEntity = new HttpEntity<>(httpHeaders);

        Assert.assertNotNull(loaDocumentStoreResponse);
        Assert.assertNotNull(loaDocumentStoreResponse.getBody());
        Assert.assertNotNull(loaDocumentStoreResponse.getBody().getData());
        Assert.assertNotNull(loaDocumentStoreResponse.getBody().getData().getDocumentStore());
        Assert.assertNotNull(loaDocumentStoreResponse.getBody().getData().getDocumentStore().getUniqueDocId());
        Assert.assertTrue(loaDocumentStoreResponse.getBody().getData().getDocumentStore().getUniqueDocId().length() > 1);

        String uniqueDocId = loaDocumentStoreResponse.getBody().getData().getDocumentStore().getUniqueDocId();

        ResponseEntity <LoaDocumentMgmtErrorResponse> loaDocumentMgmtErrorResponse =
                testRestTemplate.exchange(baseUrl + "286412844/documents/" + uniqueDocId, HttpMethod.DELETE,
                        httpEntity, LoaDocumentMgmtErrorResponse.class);

        Assert.assertNotNull(loaDocumentMgmtErrorResponse);
        Assert.assertNotNull(loaDocumentMgmtErrorResponse.getBody());
        Assert.assertEquals(HttpStatus.BAD_REQUEST, loaDocumentMgmtErrorResponse.getStatusCode());
    }

    @Test
    public void validateDeleteDocumentMetadataWhenUserIDisEmpty() {
        ResponseEntity <LoaDocumentStoreResponse> loaDocumentStoreResponse =
                testRestTemplate.exchange(baseUrl + "286412844/documents", HttpMethod.POST,
                        prepareMetadataForDocuments(loaDocumentPdfDocument,
                                Constants.LOCAL_CATEGORY_SUB_CATEGORY_ID_1, Constants.LOCAL_CATEGORY_SUB_CATEGORY_ID_1,
                                Constants.LOCAL_USER_ID_FOR_DELETE_ARCHIVE, "2017-09-16", "Sample note -1", false,
                                null,null,null,null),
                        LoaDocumentStoreResponse.class);

        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set(Constants.LOA_ID_PATH_PARAMETER, " ");
        HttpEntity<Void> httpEntity = new HttpEntity<>(httpHeaders);

        Assert.assertNotNull(loaDocumentStoreResponse);
        Assert.assertNotNull(loaDocumentStoreResponse.getBody());
        Assert.assertNotNull(loaDocumentStoreResponse.getBody().getData());
        Assert.assertNotNull(loaDocumentStoreResponse.getBody().getData().getDocumentStore());
        Assert.assertNotNull(loaDocumentStoreResponse.getBody().getData().getDocumentStore().getUniqueDocId());
        Assert.assertTrue(loaDocumentStoreResponse.getBody().getData().getDocumentStore().getUniqueDocId().length() > 1);

        String uniqueDocId = loaDocumentStoreResponse.getBody().getData().getDocumentStore().getUniqueDocId();

        ResponseEntity <LoaDocumentDeleteResponse> loaDocumentDeleteResponse =
                testRestTemplate.exchange(baseUrl + "286412844/documents/" + uniqueDocId, HttpMethod.DELETE,
                        httpEntity, LoaDocumentDeleteResponse.class);

        Assert.assertNotNull(loaDocumentDeleteResponse);
        Assert.assertNotNull(loaDocumentDeleteResponse.getBody());
        Assert.assertNotNull(loaDocumentDeleteResponse.getBody().getData());
        Assert.assertNotNull(loaDocumentDeleteResponse.getBody().getData().getDocumentArchive());
        Assert.assertEquals("file-example_PDF_1MB.pdf" + " document of loaId:"
                + "286412844" + " deleted successfully", loaDocumentDeleteResponse.getBody().getData().getDocumentArchive().getMessage());
    }


    @Test
    public void validateDeleteDocumentMetadataWhenWBUserIDisAlphaNumeric() {
        ResponseEntity <LoaDocumentStoreResponse> loaDocumentStoreResponse =
                testRestTemplate.exchange(baseUrl + "286412844/documents", HttpMethod.POST,
                        prepareMetadataForDocuments(loaDocumentPdfDocument,
                                Constants.LOCAL_CATEGORY_SUB_CATEGORY_ID_1, Constants.LOCAL_CATEGORY_SUB_CATEGORY_ID_1,
                                Constants.LOCAL_USER_ID_FOR_DELETE_ARCHIVE, "2017-09-16", "Sample note -1", false,
                                null,null,null,null),
                        LoaDocumentStoreResponse.class);

        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set(Constants.LOA_ID_PATH_PARAMETER, "a12345");
        HttpEntity<Void> httpEntity = new HttpEntity<>(httpHeaders);

        Assert.assertNotNull(loaDocumentStoreResponse);
        Assert.assertNotNull(loaDocumentStoreResponse.getBody());
        Assert.assertNotNull(loaDocumentStoreResponse.getBody().getData());
        Assert.assertNotNull(loaDocumentStoreResponse.getBody().getData().getDocumentStore());
        Assert.assertNotNull(loaDocumentStoreResponse.getBody().getData().getDocumentStore().getUniqueDocId());
        Assert.assertTrue(loaDocumentStoreResponse.getBody().getData().getDocumentStore().getUniqueDocId().length() > 1);

        String uniqueDocId = loaDocumentStoreResponse.getBody().getData().getDocumentStore().getUniqueDocId();
        ResponseEntity <LoaDocumentMgmtErrorResponse> loaDocumentMgmtErrorResponse =
                testRestTemplate.exchange(baseUrl + "286412844/documents/" + uniqueDocId, HttpMethod.DELETE,
                        httpEntity, LoaDocumentMgmtErrorResponse.class);

        Assert.assertNotNull(loaDocumentMgmtErrorResponse);
        Assert.assertNotNull(loaDocumentMgmtErrorResponse.getBody());
        Assert.assertEquals(HttpStatus.BAD_REQUEST, loaDocumentMgmtErrorResponse.getStatusCode());
    }

    @Test
    public void validateDeleteDocumentMetadataWhenWBUserIDisNegative() {
        ResponseEntity <LoaDocumentStoreResponse> loaDocumentStoreResponse =
                testRestTemplate.exchange(baseUrl + "286412844/documents", HttpMethod.POST,
                        prepareMetadataForDocuments(loaDocumentPdfDocument,
                                Constants.LOCAL_CATEGORY_SUB_CATEGORY_ID_1, Constants.LOCAL_CATEGORY_SUB_CATEGORY_ID_1,
                                Constants.LOCAL_USER_ID_FOR_DELETE_ARCHIVE, "2017-09-16", "Sample note -1", false,
                                null,null,null,null),
                        LoaDocumentStoreResponse.class);

        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set(Constants.LOA_ID_PATH_PARAMETER, "-1");
        HttpEntity<Void> httpEntity = new HttpEntity<>(httpHeaders);

        Assert.assertNotNull(loaDocumentStoreResponse);
        Assert.assertNotNull(loaDocumentStoreResponse.getBody());
        Assert.assertNotNull(loaDocumentStoreResponse.getBody().getData());
        Assert.assertNotNull(loaDocumentStoreResponse.getBody().getData().getDocumentStore());
        Assert.assertNotNull(loaDocumentStoreResponse.getBody().getData().getDocumentStore().getUniqueDocId());
        Assert.assertTrue(loaDocumentStoreResponse.getBody().getData().getDocumentStore().getUniqueDocId().length() > 1);

        String uniqueDocId = loaDocumentStoreResponse.getBody().getData().getDocumentStore().getUniqueDocId();

        ResponseEntity <LoaDocumentMgmtErrorResponse> loaDocumentMgmtErrorResponse =
                testRestTemplate.exchange(baseUrl + "286412844/documents/" + uniqueDocId, HttpMethod.DELETE,
                        httpEntity, LoaDocumentMgmtErrorResponse.class);

        Assert.assertNotNull(loaDocumentMgmtErrorResponse);
        Assert.assertNotNull(loaDocumentMgmtErrorResponse.getBody());
        Assert.assertEquals(HttpStatus.BAD_REQUEST, loaDocumentMgmtErrorResponse.getStatusCode());
    }

    @Test
    public void validateDeleteDocumentMetadataWhenLoaIDHeaderIsMissing() {
        // Prepare document for deletion
        ResponseEntity<LoaDocumentStoreResponse> loaDocumentStoreResponse =
                testRestTemplate.exchange(baseUrl + "286412844/documents", HttpMethod.POST,
                        prepareMetadataForDocuments(loaDocumentPdfDocument,
                                Constants.LOCAL_CATEGORY_SUB_CATEGORY_ID_1, Constants.LOCAL_CATEGORY_SUB_CATEGORY_ID_1,
                                Constants.LOCAL_USER_ID_FOR_DELETE_ARCHIVE, "2017-09-16", "Sample note -1", false,
                                null, null, null, null),
                        LoaDocumentStoreResponse.class);
        String uniqueDocId = loaDocumentStoreResponse.getBody().getData().getDocumentStore().getUniqueDocId();
        // Do not set WBUserID header
        HttpHeaders httpHeaders = new HttpHeaders();
        HttpEntity<Void> httpEntity = new HttpEntity<>(httpHeaders);
        ResponseEntity<String> response = testRestTemplate.exchange(
                baseUrl + "286412844/documents/" + uniqueDocId, HttpMethod.DELETE, httpEntity, String.class);
        // Assert error response
        Assert.assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        Assert.assertTrue(response.getBody().contains("individualId must not be empty or whitespace"));
    }

    // The below test case is Invalid because in Spring Boot 3.x.x header(key) name cannot be empty & it is expecting some value should be given.
    // Getting error as Incorrect HTTP Header name.
/*    @Test
    public void validateDeleteDocumentMetadataWithEmptyWBUserIDHeaderAndWBUserID() {
        ResponseEntity <LoaDocumentStoreResponse> loaDocumentStoreResponse =
                testRestTemplate.exchange(baseUrl + "286412844/documents", HttpMethod.POST,
                        prepareMetadataForDocuments(loaDocumentPdfDocument,
                                Constants.LOCAL_CATEGORY_SUB_CATEGORY_ID_1, Constants.LOCAL_CATEGORY_SUB_CATEGORY_ID_1,
                                Constants.LOCAL_USER_ID_FOR_DELETE_ARCHIVE, "2017-09-16", "Sample note -1", false,
                                null,null,null,null),
                        LoaDocumentStoreResponse.class);


        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set("", "");
        HttpEntity httpEntity = new HttpEntity(httpHeaders);

        Assert.assertNotNull(loaDocumentStoreResponse);
        Assert.assertNotNull(loaDocumentStoreResponse.getBody());
        Assert.assertNotNull(loaDocumentStoreResponse.getBody().getData());
        Assert.assertNotNull(loaDocumentStoreResponse.getBody().getData().getDocumentStore());
        Assert.assertNotNull(loaDocumentStoreResponse.getBody().getData().getDocumentStore().getUniqueDocId());
        Assert.assertTrue(loaDocumentStoreResponse.getBody().getData().getDocumentStore().getUniqueDocId().length() > 1);

        String uniqueDocId = loaDocumentStoreResponse.getBody().getData().getDocumentStore().getUniqueDocId();

        ResponseEntity <LoaDocumentDeleteResponse> loaDocumentDeleteResponse =
                testRestTemplate.exchange(baseUrl + "286412844/documents/" + uniqueDocId, HttpMethod.DELETE,
                        httpEntity, LoaDocumentDeleteResponse.class);

        Assert.assertNotNull(loaDocumentDeleteResponse);
        Assert.assertNotNull(loaDocumentDeleteResponse.getBody());
        Assert.assertNotNull(loaDocumentDeleteResponse.getBody().getData());
        Assert.assertNotNull(loaDocumentDeleteResponse.getBody().getData().getDocumentArchive());
        Assert.assertEquals("file-example_PDF_1MB.pdf" + " document of loaId:"
                + "286412844" + " deleted successfully", loaDocumentDeleteResponse.getBody().getData().getDocumentArchive().getMessage());
    }*/

    @Test
    public void validateDeleteDocumentMetadataWithHeadersNull() {
        ResponseEntity <LoaDocumentStoreResponse> loaDocumentStoreResponse =
                testRestTemplate.exchange(baseUrl + "286412844/documents", HttpMethod.POST,
                        prepareMetadataForDocuments(loaDocumentPdfDocument,
                                Constants.LOCAL_CATEGORY_SUB_CATEGORY_ID_1, Constants.LOCAL_CATEGORY_SUB_CATEGORY_ID_1,
                                Constants.LOCAL_USER_ID_FOR_DELETE_ARCHIVE, "2017-09-16", "Sample note -1", false,
                                null,null,null,null),
                        LoaDocumentStoreResponse.class);


        HttpEntity<Void> httpEntity = new HttpEntity<>(null);

        Assert.assertNotNull(loaDocumentStoreResponse);
        Assert.assertNotNull(loaDocumentStoreResponse.getBody());
        Assert.assertNotNull(loaDocumentStoreResponse.getBody().getData());
        Assert.assertNotNull(loaDocumentStoreResponse.getBody().getData().getDocumentStore());
        Assert.assertNotNull(loaDocumentStoreResponse.getBody().getData().getDocumentStore().getUniqueDocId());
        Assert.assertTrue(loaDocumentStoreResponse.getBody().getData().getDocumentStore().getUniqueDocId().length() > 1);

        String uniqueDocId = loaDocumentStoreResponse.getBody().getData().getDocumentStore().getUniqueDocId();

        ResponseEntity <LoaDocumentDeleteResponse> loaDocumentDeleteResponse =
                testRestTemplate.exchange(baseUrl + "286412844/documents/" + uniqueDocId, HttpMethod.DELETE,
                        httpEntity, LoaDocumentDeleteResponse.class);

        Assert.assertNotNull(loaDocumentDeleteResponse);
        Assert.assertNotNull(loaDocumentDeleteResponse.getBody());
        Assert.assertNotNull(loaDocumentDeleteResponse.getBody().getData());
        Assert.assertNotNull(loaDocumentDeleteResponse.getBody().getData().getDocumentArchive());
        Assert.assertEquals("file-example_PDF_1MB.pdf" + " document of loaId:"
                + "286412844" + " deleted successfully", loaDocumentDeleteResponse.getBody().getData().getDocumentArchive().getMessage());
    }

    @Test
    public void validateDeleteDocumentMetadataWithNullUniqueID() {

        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set(Constants.LOA_ID_PATH_PARAMETER, String.valueOf(Constants.LOCAL_USER_ID_FOR_DELETE_ARCHIVE));
        HttpEntity<Void> httpEntity = new HttpEntity<>(httpHeaders);

        ResponseEntity <LoaDocumentMgmtErrorResponse> loaDocumentMgmtErrorResponse =
                testRestTemplate.exchange(baseUrl + "286412844/documents/null", HttpMethod.DELETE,
                        httpEntity, LoaDocumentMgmtErrorResponse.class);

        Assert.assertNotNull(loaDocumentMgmtErrorResponse);
        Assert.assertNotNull(loaDocumentMgmtErrorResponse.getBody());
        Assert.assertEquals(HttpStatus.NOT_FOUND, loaDocumentMgmtErrorResponse.getStatusCode());
    }

    @Test
    public void validateDeleteDocumentMetadataWithInvalidLoaId() {
        ResponseEntity <LoaDocumentStoreResponse> loaDocumentStoreResponse =
                testRestTemplate.exchange(baseUrl + "286412844/documents", HttpMethod.POST,
                        prepareMetadataForDocuments(loaDocumentPdfDocument,
                                Constants.LOCAL_CATEGORY_SUB_CATEGORY_ID_1, Constants.LOCAL_CATEGORY_SUB_CATEGORY_ID_1,
                                Constants.LOCAL_USER_ID_FOR_DELETE_ARCHIVE, "2017-09-16", "Sample note -1", false,
                                null,null,null,null),
                        LoaDocumentStoreResponse.class);

        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set(Constants.LOA_ID_PATH_PARAMETER, String.valueOf(Constants.LOCAL_USER_ID_FOR_DELETE_ARCHIVE));
        HttpEntity<Void> httpEntity = new HttpEntity<>(httpHeaders);

        Assert.assertNotNull(loaDocumentStoreResponse);
        Assert.assertNotNull(loaDocumentStoreResponse.getBody());
        Assert.assertNotNull(loaDocumentStoreResponse.getBody().getData());
        Assert.assertNotNull(loaDocumentStoreResponse.getBody().getData().getDocumentStore());
        Assert.assertNotNull(loaDocumentStoreResponse.getBody().getData().getDocumentStore().getUniqueDocId());
        Assert.assertTrue(loaDocumentStoreResponse.getBody().getData().getDocumentStore().getUniqueDocId().length() > 1);

        String uniqueDocId = loaDocumentStoreResponse.getBody().getData().getDocumentStore().getUniqueDocId();

        ResponseEntity <LoaDocumentMgmtErrorResponse> loaDocumentMgmtErrorResponse =
                testRestTemplate.exchange(baseUrl + "0/documents/" + uniqueDocId, HttpMethod.DELETE,
                        httpEntity, LoaDocumentMgmtErrorResponse.class);

        Assert.assertNotNull(loaDocumentMgmtErrorResponse);
        Assert.assertNotNull(loaDocumentMgmtErrorResponse.getBody());
        Assert.assertEquals(HttpStatus.BAD_REQUEST, loaDocumentMgmtErrorResponse.getStatusCode());
    }

    @Test
    public void validateDeleteDocumentMetadataWithNegativeLoaId() {
        ResponseEntity <LoaDocumentStoreResponse> loaDocumentStoreResponse =
                testRestTemplate.exchange(baseUrl + "286412844/documents", HttpMethod.POST,
                        prepareMetadataForDocuments(loaDocumentPdfDocument,
                                Constants.LOCAL_CATEGORY_SUB_CATEGORY_ID_1, Constants.LOCAL_CATEGORY_SUB_CATEGORY_ID_1,
                                Constants.LOCAL_USER_ID_FOR_DELETE_ARCHIVE, "2017-09-16", "Sample note -1", false,
                                null,null,null,null),
                        LoaDocumentStoreResponse.class);

        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set(Constants.LOA_ID_PATH_PARAMETER, String.valueOf(Constants.LOCAL_USER_ID_FOR_DELETE_ARCHIVE));
        HttpEntity<Void> httpEntity = new HttpEntity<>(httpHeaders);

        Assert.assertNotNull(loaDocumentStoreResponse);
        Assert.assertNotNull(loaDocumentStoreResponse.getBody());
        Assert.assertNotNull(loaDocumentStoreResponse.getBody().getData());
        Assert.assertNotNull(loaDocumentStoreResponse.getBody().getData().getDocumentStore());
        Assert.assertNotNull(loaDocumentStoreResponse.getBody().getData().getDocumentStore().getUniqueDocId());
        Assert.assertTrue(loaDocumentStoreResponse.getBody().getData().getDocumentStore().getUniqueDocId().length() > 1);

        String uniqueDocId = loaDocumentStoreResponse.getBody().getData().getDocumentStore().getUniqueDocId();

        ResponseEntity <LoaDocumentMgmtErrorResponse> loaDocumentMgmtErrorResponse =
                testRestTemplate.exchange(baseUrl + "-1/documents/" + uniqueDocId, HttpMethod.DELETE,
                        httpEntity, LoaDocumentMgmtErrorResponse.class);

        Assert.assertNotNull(loaDocumentMgmtErrorResponse);
        Assert.assertNotNull(loaDocumentMgmtErrorResponse.getBody());
        Assert.assertEquals(HttpStatus.BAD_REQUEST, loaDocumentMgmtErrorResponse.getStatusCode());
    }

    @Test
    public void validateDeleteDocumentMetadataWithBigLoaId() {
        ResponseEntity <LoaDocumentStoreResponse> loaDocumentStoreResponse =
                testRestTemplate.exchange(baseUrl + "286412844/documents", HttpMethod.POST,
                        prepareMetadataForDocuments(loaDocumentPdfDocument,
                                Constants.LOCAL_CATEGORY_SUB_CATEGORY_ID_1, Constants.LOCAL_CATEGORY_SUB_CATEGORY_ID_1,
                                Constants.LOCAL_USER_ID_FOR_DELETE_ARCHIVE, "2017-09-16", "Sample note -1", false,
                                null,null,null,null),
                        LoaDocumentStoreResponse.class);

        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set(Constants.LOA_ID_PATH_PARAMETER, String.valueOf(Constants.LOCAL_USER_ID_FOR_DELETE_ARCHIVE));
        HttpEntity<Void> httpEntity = new HttpEntity<>(httpHeaders);

        Assert.assertNotNull(loaDocumentStoreResponse);
        Assert.assertNotNull(loaDocumentStoreResponse.getBody());
        Assert.assertNotNull(loaDocumentStoreResponse.getBody().getData());
        Assert.assertNotNull(loaDocumentStoreResponse.getBody().getData().getDocumentStore());
        Assert.assertNotNull(loaDocumentStoreResponse.getBody().getData().getDocumentStore().getUniqueDocId());
        Assert.assertTrue(loaDocumentStoreResponse.getBody().getData().getDocumentStore().getUniqueDocId().length() > 1);

        String uniqueDocId = loaDocumentStoreResponse.getBody().getData().getDocumentStore().getUniqueDocId();

        ResponseEntity <LoaDocumentMgmtErrorResponse> loaDocumentMgmtErrorResponse =
                testRestTemplate.exchange(baseUrl + "12345678901/documents/" + uniqueDocId, HttpMethod.DELETE,
                        httpEntity, LoaDocumentMgmtErrorResponse.class);

        Assert.assertNotNull(loaDocumentMgmtErrorResponse);
        Assert.assertNotNull(loaDocumentMgmtErrorResponse.getBody());
        Assert.assertEquals(HttpStatus.BAD_REQUEST, loaDocumentMgmtErrorResponse.getStatusCode());
    }

    @Test
    public void validateDeletedDocumentMetadataWithValidUniqueDocIdButNotMatchingLoaId() {
        ResponseEntity <LoaDocumentStoreResponse> loaDocumentStoreResponse =
                testRestTemplate.exchange(baseUrl + "286412844/documents", HttpMethod.POST,
                        prepareMetadataForDocuments(loaDocumentPdfDocument,
                                Constants.LOCAL_CATEGORY_SUB_CATEGORY_ID_1, Constants.LOCAL_CATEGORY_SUB_CATEGORY_ID_1,
                                Constants.LOCAL_USER_ID_FOR_DELETE_ARCHIVE, "2017-09-16", "Sample note -1", false,
                                null,null,null,null),
                        LoaDocumentStoreResponse.class);

        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set(Constants.LOA_ID_PATH_PARAMETER, String.valueOf(Constants.LOCAL_USER_ID_FOR_DELETE_ARCHIVE));
        HttpEntity<Void> httpEntity = new HttpEntity<>(httpHeaders);

        Assert.assertNotNull(loaDocumentStoreResponse);
        Assert.assertNotNull(loaDocumentStoreResponse.getBody());
        Assert.assertNotNull(loaDocumentStoreResponse.getBody().getData());
        Assert.assertNotNull(loaDocumentStoreResponse.getBody().getData().getDocumentStore());
        Assert.assertNotNull(loaDocumentStoreResponse.getBody().getData().getDocumentStore().getUniqueDocId());
        Assert.assertTrue(loaDocumentStoreResponse.getBody().getData().getDocumentStore().getUniqueDocId().length() > 1);

        ResponseEntity <LoaDocumentMgmtErrorResponse> loaDocumentMgmtErrorResponse =
                testRestTemplate.exchange(baseUrl + "/286412213/documents/c3VyZXR5LWFnZW5jeS1ib25kL" +
                                "XJlcG8vc3VyZXR5LWFnZW5jeS1ib25kLWRvY3VtZW50Lzk2NmFlMGU4LWE1MzgtNDk4Yy05MWQ0LTAx" +
                                "M2YxNWEzYWM5ZA==" , HttpMethod.DELETE,
                        httpEntity, LoaDocumentMgmtErrorResponse.class);

        Assert.assertNotNull(loaDocumentMgmtErrorResponse);
        Assert.assertNotNull(loaDocumentMgmtErrorResponse.getBody());
        Assert.assertEquals(HttpStatus.NOT_FOUND, loaDocumentMgmtErrorResponse.getStatusCode());
    }

    @Test
    public void validateDeleteDocumentMetadataWhenUserIDisNull() {
        ResponseEntity <LoaDocumentStoreResponse> loaDocumentStoreResponse =
                testRestTemplate.exchange(baseUrl + "286412844/documents", HttpMethod.POST,
                        prepareMetadataForDocuments(loaDocumentPdfDocument,
                                Constants.LOCAL_CATEGORY_SUB_CATEGORY_ID_1, Constants.LOCAL_CATEGORY_SUB_CATEGORY_ID_1,
                                Constants.LOCAL_USER_ID_FOR_DELETE_ARCHIVE, "2017-09-16", "Sample note -1", false,
                                null,null,null,null),
                        LoaDocumentStoreResponse.class);

        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set(Constants.LOA_ID_PATH_PARAMETER, null);
        HttpEntity<Void> httpEntity = new HttpEntity<>(httpHeaders);


        Assert.assertNotNull(loaDocumentStoreResponse);
        Assert.assertNotNull(loaDocumentStoreResponse.getBody());
        Assert.assertNotNull(loaDocumentStoreResponse.getBody().getData());
        Assert.assertNotNull(loaDocumentStoreResponse.getBody().getData().getDocumentStore());
        Assert.assertNotNull(loaDocumentStoreResponse.getBody().getData().getDocumentStore().getUniqueDocId());
        Assert.assertTrue(loaDocumentStoreResponse.getBody().getData().getDocumentStore().getUniqueDocId().length() > 1);

        String uniqueDocId = loaDocumentStoreResponse.getBody().getData().getDocumentStore().getUniqueDocId();

        ResponseEntity <LoaDocumentDeleteResponse> loaDocumentDeleteResponse =
                testRestTemplate.exchange(baseUrl + "286412844/documents/" + uniqueDocId, HttpMethod.DELETE,
                        httpEntity, LoaDocumentDeleteResponse.class);

        Assert.assertNotNull(loaDocumentDeleteResponse);
        Assert.assertNotNull(loaDocumentDeleteResponse.getBody());
        Assert.assertNotNull(loaDocumentDeleteResponse.getBody().getData());
        Assert.assertNotNull(loaDocumentDeleteResponse.getBody().getData().getDocumentArchive());
        Assert.assertEquals("file-example_PDF_1MB.pdf" + " document of loaId:"
                + "286412844" + " deleted successfully", loaDocumentDeleteResponse.getBody().getData().getDocumentArchive().getMessage());
    }

    @Test
    public void validateDeleteDocumentMetadataWhenUserIDValueIsEmpty() {
        ResponseEntity <LoaDocumentStoreResponse> loaDocumentStoreResponse =
                testRestTemplate.exchange(baseUrl + "286412844/documents", HttpMethod.POST,
                        prepareMetadataForDocuments(loaDocumentPdfDocument,
                                Constants.LOCAL_CATEGORY_SUB_CATEGORY_ID_1, Constants.LOCAL_CATEGORY_SUB_CATEGORY_ID_1,
                                Constants.LOCAL_USER_ID_FOR_DELETE_ARCHIVE, "2017-09-16", "Sample note -1", false,
                                null,null,null,null),
                        LoaDocumentStoreResponse.class);

        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set(Constants.LOA_ID_PATH_PARAMETER, "\"\"");
        HttpEntity<Void> httpEntity = new HttpEntity<>(httpHeaders);


        Assert.assertNotNull(loaDocumentStoreResponse);
        Assert.assertNotNull(loaDocumentStoreResponse.getBody());
        Assert.assertNotNull(loaDocumentStoreResponse.getBody().getData());
        Assert.assertNotNull(loaDocumentStoreResponse.getBody().getData().getDocumentStore());
        Assert.assertNotNull(loaDocumentStoreResponse.getBody().getData().getDocumentStore().getUniqueDocId());
        Assert.assertTrue(loaDocumentStoreResponse.getBody().getData().getDocumentStore().getUniqueDocId().length() > 1);

        String uniqueDocId = loaDocumentStoreResponse.getBody().getData().getDocumentStore().getUniqueDocId();

        ResponseEntity <LoaDocumentMgmtErrorResponse> loaDocumentMgmtErrorResponse =
                testRestTemplate.exchange(baseUrl + "286412844/documents/" + uniqueDocId, HttpMethod.DELETE,
                        httpEntity, LoaDocumentMgmtErrorResponse.class);

        Assert.assertNotNull(loaDocumentMgmtErrorResponse);
        Assert.assertNotNull(loaDocumentMgmtErrorResponse.getBody());
        Assert.assertEquals(HttpStatus.BAD_REQUEST, loaDocumentMgmtErrorResponse.getStatusCode());
    }

    @Test
    public void validateDeleteDocumentMetadataWhenUserIDisEmptyStringWithSpace() {
        ResponseEntity <LoaDocumentStoreResponse> loaDocumentStoreResponse =
                testRestTemplate.exchange(baseUrl + "286412844/documents", HttpMethod.POST,
                        prepareMetadataForDocuments(loaDocumentPdfDocument,
                                Constants.LOCAL_CATEGORY_SUB_CATEGORY_ID_1, Constants.LOCAL_CATEGORY_SUB_CATEGORY_ID_1,
                                Constants.LOCAL_USER_ID_FOR_DELETE_ARCHIVE, "2017-09-16", "Sample note -1", false,
                                null,null,null,null),
                        LoaDocumentStoreResponse.class);

        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set(Constants.LOA_ID_PATH_PARAMETER, "\"   \"");
        HttpEntity<Void> httpEntity = new HttpEntity<>(httpHeaders);


        Assert.assertNotNull(loaDocumentStoreResponse);
        Assert.assertNotNull(loaDocumentStoreResponse.getBody());
        Assert.assertNotNull(loaDocumentStoreResponse.getBody().getData());
        Assert.assertNotNull(loaDocumentStoreResponse.getBody().getData().getDocumentStore());
        Assert.assertNotNull(loaDocumentStoreResponse.getBody().getData().getDocumentStore().getUniqueDocId());
        Assert.assertTrue(loaDocumentStoreResponse.getBody().getData().getDocumentStore().getUniqueDocId().length() > 1);

        String uniqueDocId = loaDocumentStoreResponse.getBody().getData().getDocumentStore().getUniqueDocId();

        ResponseEntity <LoaDocumentMgmtErrorResponse> loaDocumentMgmtErrorResponse =
                testRestTemplate.exchange(baseUrl + "286412844/documents/" + uniqueDocId, HttpMethod.DELETE,
                        httpEntity, LoaDocumentMgmtErrorResponse.class);

        Assert.assertNotNull(loaDocumentMgmtErrorResponse);
        Assert.assertNotNull(loaDocumentMgmtErrorResponse.getBody());
        Assert.assertEquals(HttpStatus.BAD_REQUEST, loaDocumentMgmtErrorResponse.getStatusCode());
    }

    @Test
    public void validateDeleteDocumentMetadataWhenUserIDisNullString() {
        ResponseEntity <LoaDocumentStoreResponse> loaDocumentStoreResponse =
                testRestTemplate.exchange(baseUrl + "286412844/documents", HttpMethod.POST,
                        prepareMetadataForDocuments(loaDocumentPdfDocument,
                                Constants.LOCAL_CATEGORY_SUB_CATEGORY_ID_1, Constants.LOCAL_CATEGORY_SUB_CATEGORY_ID_1,
                                Constants.LOCAL_USER_ID_FOR_DELETE_ARCHIVE, "2017-09-16", "Sample note -1", false,
                                null,null,null,null),
                        LoaDocumentStoreResponse.class);

        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set(Constants.LOA_ID_PATH_PARAMETER, "\"null\"");
        HttpEntity<Void> httpEntity = new HttpEntity<>(httpHeaders);


        Assert.assertNotNull(loaDocumentStoreResponse);
        Assert.assertNotNull(loaDocumentStoreResponse.getBody());
        Assert.assertNotNull(loaDocumentStoreResponse.getBody().getData());
        Assert.assertNotNull(loaDocumentStoreResponse.getBody().getData().getDocumentStore());
        Assert.assertNotNull(loaDocumentStoreResponse.getBody().getData().getDocumentStore().getUniqueDocId());
        Assert.assertTrue(loaDocumentStoreResponse.getBody().getData().getDocumentStore().getUniqueDocId().length() > 1);

        String uniqueDocId = loaDocumentStoreResponse.getBody().getData().getDocumentStore().getUniqueDocId();

        ResponseEntity <LoaDocumentMgmtErrorResponse> loaDocumentMgmtErrorResponse =
                testRestTemplate.exchange(baseUrl + "286412844/documents/" + uniqueDocId, HttpMethod.DELETE,
                        httpEntity, LoaDocumentMgmtErrorResponse.class);

        Assert.assertNotNull(loaDocumentMgmtErrorResponse);
        Assert.assertNotNull(loaDocumentMgmtErrorResponse.getBody());
        Assert.assertEquals(HttpStatus.BAD_REQUEST, loaDocumentMgmtErrorResponse.getStatusCode());
    }

    @Test
    public void validateDeleteDocumentMetadataWhenWbUserIDNotFoundInRedis() {
        ResponseEntity <LoaDocumentStoreResponse> loaDocumentStoreResponse =
                testRestTemplate.exchange(baseUrl + "286412844/documents", HttpMethod.POST,
                        prepareMetadataForDocuments(loaDocumentPdfDocument,
                                Constants.LOCAL_CATEGORY_SUB_CATEGORY_ID_1, Constants.LOCAL_CATEGORY_SUB_CATEGORY_ID_1,
                                Constants.LOCAL_USER_ID_FOR_DELETE_ARCHIVE, "2017-09-16", "Sample note -1", false,
                                null,null,null,null),
                        LoaDocumentStoreResponse.class);

        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set(Constants.LOA_ID_PATH_PARAMETER, String.valueOf(Constants.LOCAL_USER_ID_11111_NOT_FOUND_IN_REDIS));
        HttpEntity<Void> httpEntity = new HttpEntity<>(httpHeaders);


        Assert.assertNotNull(loaDocumentStoreResponse);
        Assert.assertNotNull(loaDocumentStoreResponse.getBody());
        Assert.assertNotNull(loaDocumentStoreResponse.getBody().getData());
        Assert.assertNotNull(loaDocumentStoreResponse.getBody().getData().getDocumentStore());
        Assert.assertNotNull(loaDocumentStoreResponse.getBody().getData().getDocumentStore().getUniqueDocId());
        Assert.assertTrue(loaDocumentStoreResponse.getBody().getData().getDocumentStore().getUniqueDocId().length() > 1);

        String uniqueDocId = loaDocumentStoreResponse.getBody().getData().getDocumentStore().getUniqueDocId();
        ResponseEntity<LoaDocumentDeleteResponse> loaDocumentDeleteResponse =
                testRestTemplate.exchange(baseUrl + "286412844/documents/" + uniqueDocId, HttpMethod.DELETE,
                        httpEntity, LoaDocumentDeleteResponse.class);

        // Assert that a 400 BAD_REQUEST is returned when INDIVIDUAL-ID header is missing
        Assert.assertEquals(HttpStatus.BAD_REQUEST, loaDocumentDeleteResponse.getStatusCode());
        Assert.assertNotNull(loaDocumentDeleteResponse.getBody());
        // Optionally, check error message
        // Assert.assertTrue(loaDocumentDeleteResponse.getBody().toString().contains("individualId must not be empty or whitespace"));
    }
}
